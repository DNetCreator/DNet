DNet Setup

- Put DNet onto the Desktop; it will only work there

- Double click "Setup"
- If Mac says "unidentified developer", deal with that
- When it finally opens do what it says

- After that executable has run, Mac still blocks some of the other executables
- For that, go to the "bin" folder
- You will need to click all executables one by one to "trust" the developer or the executable

- Close all terminals if open
- Go back to main folder
- Double click restart
- Double click Start


FIREWALL ISSUE
- Mac firewall will block send and receive functionality
- Go to Mac system preferences and find firewall
- If firewall is on, go to firewall options, and allow connections for PHP
- If firewall is off, send and receive functionality will work
- If firewall is on, but no PHP, allow PHP to make connections when a pop up shows up