import subprocess
import os

user = subprocess.check_output('whoami');
directory = "/Users/{}/Desktop/DNet/laptop".format(user)
complete_check = directory.replace("\n", "")

# change directory to laptop verson
os.chdir(complete_check)
# start laptop server
subprocess.call('php -S localhost:7890 -t . &', shell = True);
subprocess.call('cd /Users/$(whoami)/Desktop/DNet/laptop/home/file_sharing; php recvNotification.php &', shell = True);
subprocess.call('cd /Users/$(whoami)/Desktop/DNet/laptop/home/users_online; php recv.php &', shell = True);
subprocess.call('cd /Users/$(whoami)/Desktop/DNet/laptop/home/chat; php recvAllChat.php &', shell = True);
#subprocess.call('cd /Users/$(whoami)/Desktop/DNet/bin; ./status &', shell = True);