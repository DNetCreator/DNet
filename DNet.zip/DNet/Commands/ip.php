<?php

for ($i=0; $i < 5; $i++) 
{
	if (exec("ipconfig getifaddr en".$i) != "") 
	{
		file_put_contents("laptop/ip.txt", exec("ipconfig getifaddr en".$i));
		break;
	}
}

?>