<?php

session_start();

system("cd ../laptop/home/users_online; php send.php " . "Iridium" . " offline &");


?>