import sys
import os

fileDirectory = sys.argv[1:];
fileDirectory = ",".join(fileDirectory);


print "File(s) Copied to Clipboard. Paste Clipboard where Needed in DNet"
print "----------------------------------"
os.system("echo {} | pbcopy".format(fileDirectory))