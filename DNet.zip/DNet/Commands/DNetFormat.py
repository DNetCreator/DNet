import os
import subprocess
subprocess.call('clear')

fileDirectory = raw_input("Drag a FILE or FOLDER below then press ENTER\n")
fileDirectory = fileDirectory[:-1]

user = os.uname()[1].split(".");

os.system("python /Users/{}/Desktop/DNet/Commands/DNetFormat2.py {}".format(user[0], fileDirectory));
