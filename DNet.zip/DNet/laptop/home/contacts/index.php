<?php

// --------------------Variables for Login--------------------
session_start();
error_reporting(0);

if (isset($_SESSION['user'])) 
{
} else 
{
	die(header('Location: /login'));
}

system("cd ../users_online; php send.php " . $_SESSION['user'] . " online &");
#system("../../../bin/checkStatus");
system("cd ../users_online; php status.php");
// --------------------Variables for Login--------------------

$color = file_get_contents("../../userData/".$_SESSION['user']."/settings.json");
$color = json_decode($color, true);
$color = $color['color'];

$font = file_get_contents("../../userData/".$_SESSION['user']."/overallColor.json");
$font = json_decode($font, true);
$font = $font['color'];



$contact_username = $_POST['contact_username'];
$contact_ipAddress = $_POST['contact_ipAddress'];
if (isset($contact_username) && isset($contact_ipAddress) && !empty($contact_username) && !empty($contact_ipAddress)) 
{		
	$contacts_txt = fopen("../../userData/".$_SESSION['user']."/contacts.txt", 'a');
	$format = $contact_username.'-'.$contact_ipAddress.'|';
	fwrite($contacts_txt, $format);
	fclose($contacts_txt);
}
$name_and_IP_deleted = $_POST['name_and_IP_deleted'];
if (isset($name_and_IP_deleted)) 
{
	$file = fopen("../../userData/".$_SESSION['user']."/contacts.txt", 'wb');
	fwrite($file, $name_and_IP_deleted);
	fclose($file);
	header("Location: /home/contacts/index.php");
}

$sendFileData = $_POST['sendFileData'];
if (isset($sendFileData)) 
{
	$sendFileData = explode('-', $sendFileData);
	$type = $sendFileData[0];
	// $username = $sendFileData[1];
	$ipAddress = $sendFileData[1];

	// Make JSON data
	$fileJson = fopen('../file_sharing/sendFileData.json', 'wb');
	$jsonData->type = $type;
	// $jsonData->username = $username;
	$jsonData->ipAddress = $ipAddress;
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($fileJson, $jsonDataEncoded);
	fclose($fileJson);
}

$chatData = $_POST['chatData'];
if (isset($chatData)) 
{
	$chatData = explode('-', $chatData);
	$type = $chatData[0];
	$ipAddress = $chatData[1];

	// Make JSON data
	$fileJson = fopen('../chat/chatData.json', 'wb');
	$jsonData->type = $type;
	// $jsonData->username = $username;
	$jsonData->ipAddress = $ipAddress;
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($fileJson, $jsonDataEncoded);
	fclose($fileJson);
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>DNet | Contacts</title>
	<link rel="shortcut icon" type="image/png" href="/icons/logo.png/">
	<link rel="stylesheet" type="text/css" href="/home/contacts/index.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
</head>
<body>
	<div class="main">
		<div class="header" style="background-color: <?php echo $color ?>">
			<img onclick="showSidebar()" id="left_ham" src="../../icons/hamburger_lines.png">
			<img onclick="showNotifications()" id="right_ham" src="../../icons/hamburger_lines.png">
			<p style="color: <?php echo $font?>">Contacts</p>
		</div>
		<script src="/dependencies/jquery.js"></script>
		<script type="text/javascript">
			function showSidebar()
			{
				if($(".sidebar").css("display") == 'block')
				{
					$(".sidebar").css("display", "none");
				} else if ($(".sidebar").css("display") == 'none')
				{
					$(".sidebar").css("display", "block");
				}
			}
			function showNotifications()
			{
				if($(".notifications").css("display") == 'block')
				{
					$(".notifications").css("display", "none");
				} else if ($(".notifications").css("display") == 'none')
				{
					$(".notifications").css("display", "block");
				}
			}
			$(document).ready(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						console.log(dataArray[0].split("\t")[0]);
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			}, 5000);
			$(document).ready(function() {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--)
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			}, 5000);
		</script>
		<div class="sidebar" id="sidebar">
			<div id="sidebarItem0-1" style="padding: 5%">
				<a href="/home"><img src="/icons/logo.png">
				<p><?php echo $_SESSION['user'] ?></p><br></a>
			</div>
			<hr>
			<a href="/home/chat"><div id="sidebarItem1-1" style="padding: 5%;">
				<p>Chat</p>
			</div></a>
			<a href="/home/file_sharing"><div id="sidebarItem1-2" style="padding: 5%;">
				<p>File Sharing</p>
			</div></a>
			<hr>
			<a href="/home/contacts"><div id="sidebarItem2-1" style="padding: 5%; background-color: <?php echo $color ?>">
				<p>Contacts</p>
			</div></a>
			<hr>
			<a href="/home/users_online"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Online Users</p>
			</div></a>
			<a href="/home/settings"><div id="sidebarItem3-3" style="padding: 5%;">
				<p>Settings</p>
			</div></a>
			<hr>
			<!-- Help Section -->
			<a href="/home/contacts/help.txt"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Help</p>
			</div></a>
			<hr>
			<a href="/home/logout"><div id="sidebarItem4-1" style="padding: 5%;">
				<p>Logout</p>
			</div></a>
		</div>
		<div class="contacts">
			<div class="addPerson" style="background-color: <?php echo $color ?>">
				<input id="contact_username" type="text" name="name" placeholder="Contact's Name"><br>
				<input id="contact_ipAddress" type="text" name="ip" placeholder="Contact's IP Address"><br>
				<button id="cancel" onclick="cancelPersonToFile()">Cancel</button>
				<button id="add" onclick="savePersonToFile()">Add Person</button>
			</div>
			<div class="contacts_list" id="contacts_list" style="background-color: <?php echo $color ?>">
				<div id="my_info">
					<b><p id="name" style="color: <?php echo $font?>">You - <?php echo $_SESSION['user']; ?></p></b><br>
					<p id="ip" style="color: <?php echo $font?>"><?php echo file_get_contents("../../ip.txt") ?></p>
					<a href="#" title="Add User"><img onclick="addNewPerson()" id="add_button" src="../../icons/add.png"></a>
				</div>
			</div>
		</div>
		<script src="/dependencies/jquery.js"></script>
		<script type="text/javascript">
			$(document).ready(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						var name_and_IP = data.split("|");
						for (var i = 0; i < name_and_IP.length-1; i++) 
						{
							var name_and_IPs = name_and_IP[i];
							var contact_information = name_and_IPs.split("-");
							var username = contact_information[0];
							var ipAddress = contact_information[1];

							var txt1 = '<div id="my_info"> \
										<b><p id="name" style="color: <?php echo $font?>">' + username +'</p></b><br> \
										<p id="ip" style="color: <?php echo $font?>">' + ipAddress + '</p> \
										<a href="#"><img id="file_sharing_icon" onclick="sendFileToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/file_sharing.png" title="Send File To User"></a> \
										<a href="#"><img id="message_icon" onclick="sendMessageToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/message.png" title="Send Message To User"></a> \
										<a href="#"><img id="delete_icon" onclick="deleteUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/delete.png" title="Delete User"></a> \
										</div>'
							$(".contacts_list").append(txt1);
						}
					}
				};
				xhttp.open("POST", "/userData/<?php echo $_SESSION['user'] ?>/contacts.txt", true);
				xhttp.send();
			});
			function sendFileToUser(username, ipAddress)
			{
				console.log("sendFileToUser: " + username + ", " + ipAddress);
				// The data is taken. 

				// The type is Sending_File
				var type = 'send_file';
				// Type is saved along with data
				var data = type + '-' + ipAddress
				// XML Request sends to PHP
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/contacts/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "sendFileData=" + data;
				console.log(data);
				xhttp.send(data);
				setTimeout(function(){ document.location.href = '/home/file_sharing/index.php'; }, 500);
				// PHP makes JSON file with data inside it

				// The Page will redirect
				// It will read from the JSON file (Don't know how I am going to make seperate ones for shortcut and dashboard versions)
			}
			function sendMessageToUser(username, ipAddress)
			{
				console.log("sendMessageToUser: " + username + ", " + ipAddress);

				var type = 'send_message';

				var data = type + '-' + ipAddress;

				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/contacts/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "chatData=" + data;
				console.log(data);
				xhttp.send(data);
				setTimeout(function(){ document.location.href = '/home/chat/index.php'; }, 500);

			}
			function deleteUser(username, ipAddress)
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						var name_and_IP_deleted = data.replace(username + "-" + ipAddress + "|", "")
						var xhttp = new XMLHttpRequest();
						xhttp.open("POST", "/home/contacts/index.php", true);
						xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
						var data = "name_and_IP_deleted=" + name_and_IP_deleted;
						xhttp.send(data);
					}
				};
				xhttp.open("POST", "/userData/<?php echo $_SESSION['user'] ?>/contacts.txt", true);
				xhttp.send();
				setTimeout(function(){ document.location.href = '/home/contacts/index.php'; }, 400);
			}			
			function addNewPerson()
			{
				document.getElementById('contacts_list').style.opacity = 0.3;
				document.getElementById('sidebar').style.opacity = 0.3;
				document.getElementById('notifications').style.opacity = 0.3;
				document.getElementById('online_users').style.opacity = 0.3;	
				$(".addPerson").show()
			}
			function savePersonToFile()
			{
				var contact_username = document.getElementById('contact_username');
				var contact_ipAddress = document.getElementById('contact_ipAddress');
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/contacts/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "contact_username=" + encodeURIComponent(contact_username.value) + "&contact_ipAddress=" + encodeURIComponent(contact_ipAddress.value);
				xhttp.send(data);
				if (contact_username.value.length > 0 && contact_ipAddress.value.length > 0) 
				{
					var txt1 = "<div id='my_info'><b><p id='name' style=\"color: <?php echo $font?>\">" + contact_username.value + "</p></b><br><p style=\"color: <?php echo $font?>\" id='ip'>" + contact_ipAddress.value + "</p><a href='#''></div>";
					$(".contacts_list").append(txt1);
				}				
				document.getElementById('contacts_list').style.opacity = 1;
				document.getElementById('sidebar').style.opacity = 1;
				document.getElementById('notifications').style.opacity = 1;
				document.getElementById('online_users').style.opacity = 1;
				$(".addPerson").hide()

				document.getElementById('contact_username').value = "";
				document.getElementById('contact_ipAddress').value = "";	
				setTimeout(function(){document.location.href = "/home/contacts"}, 300);	
			}
			function cancelPersonToFile()
			{
				document.getElementById('contacts_list').style.opacity = 1;
				document.getElementById('sidebar').style.opacity = 1;
				document.getElementById('notifications').style.opacity = 1;
				document.getElementById('online_users').style.opacity = 1;
				$(".addPerson").hide()
				document.getElementById('contact_username').value = "";
				document.getElementById('contact_ipAddress').value = "";
			}
		</script>		
		<div class="notifications" id="notifications">
			<div id="notificationsItem0-1" style="padding: 5%; color:white">
				<label>Notifications</label><br>
			</div>
			<hr style="margin-top: 0%;">
			<div id="notificationsItem0-2">
				<ul type="circle" id="notificationsList">
					
				</ul>
			</div>
		</div>
		<div class="online_users" id="online_users">			
			<hr>
			<div id="online_usersItem0-1" style="padding: 5%; color:white">
				<label>Online Users</label><br>
			</div>
			<hr style="margin-top: 0%;">
			<<div id="online_usersItem0-2" style="color: white">
				<ul type="circle" id="list">
					
				</ul>
			</div>
		</div>
	</div>
</body>
</html>