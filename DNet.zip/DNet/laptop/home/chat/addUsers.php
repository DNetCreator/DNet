<?php

// TCP Connection 
error_reporting(0);

// Makes Socket

$chatFile = file_get_contents('addUsers.json');
$chatFile = json_decode($chatFile, true);
$ips = explode(" ", $chatFile['ips']);
$port = $chatFile['port'];

// Ecrypted AES Keys with Public Key
$file = file_get_contents('chatData/'.$port.'keys.json');
$file = json_decode($file, true);
$AESkey = $file['key'];
$AESiv = $file['iv'];

$number = sizeof($ips);

$file = file_get_contents('chatData/'.$port.'data.json');
$file = json_decode($file, true);
$init = $file['initiator'];

if ($init != file_get_contents("../../ip.txt")) 
{
	exit("You are not admin. Exiting...");
}

// Writing and reading key data

for ($i=0; $i < sizeof($ips); $i++) 
{ 
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	socket_bind($socket, file_get_contents("../../ip.txt"), 6789);
	socket_listen($socket);
	
	echo "[*] Listening on " . file_get_contents("../../ip.txt") . ":6789\n";
	echo "[*] Listening for ".  $number . " Connections\n";
	$connectedSocket = socket_accept($socket);
	echo "[*] Connetion Found.\n";
	
	// Recieve Public Key
	$publicKeyData = socket_read($connectedSocket, 4096);
	socket_write($connectedSocket, '.');
	$publicKey = openssl_get_publickey($publicKeyData);

	// Ecrypted AES Keys with Public Key
	openssl_public_encrypt($AESkey, $KEY, $publicKey);
	openssl_public_encrypt($AESiv, $IV, $publicKey);

	// Send AES Keys
	socket_write($connectedSocket, $KEY);
	socket_read($connectedSocket, 1);
	socket_write($connectedSocket, $IV);
	socket_read($connectedSocket, 1);

	sleep(1);
	$number = $number - 1;
	echo "------------------------------\n";

	socket_close($connectedSocket);
}


echo "[*] Process complete. This terminal can now be closed.\n";


?>