<?php


// Important Variables
$portNo = $argv[2];
$userData = file_get_contents("chatData/".$portNo."data.json");
$userData = json_decode($userData, true);

$ips = explode(" ", $userData['ips']);
$port = $userData['port'];
$username = $userData['username'];

// AES Keys
$userData = file_get_contents("chatData/".$portNo."keys.json");
$userData = json_decode($userData, true);

$key = $userData['key'];
$iv = $userData['iv'];

$socket = socket_create(AF_INET, SOCK_DGRAM, 0);

$message = $argv[1];

date_default_timezone_set("Asia/Dubai");

$ip = file_get_contents("../../ip.txt");

$format = $username.'-'.$message.'-'.date("h:i A").'-'.$ip."|";
$encryptedMessage = openssl_encrypt($format, 'aes-256-cbc', $key, 0, $iv);
$encryptedMessage = $encryptedMessage.'.'.$portNo;
for ($i=0; $i < sizeof($ips); $i++) 
{ 
	if ($ips[$i] == file_get_contents("../../ip.txt")) {
		continue;
	}
	else
	{
		socket_sendto($socket, $encryptedMessage, strlen($encryptedMessage), 0, $ips[$i], 6782);
	}
	//socket_sendto($socket, $encryptedMessage, strlen($encryptedMessage), 0, $ips[$i], 6782);
}

?>