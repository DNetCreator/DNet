<?php

error_reporting(0);
$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
socket_bind($socket, file_get_contents("../../ip.txt"), 6782);

while (true) 
{
	socket_recvfrom($socket, $messagesRecv, 1000, 0, $rip, $rport);
	$message = explode(".", $messagesRecv);
	$encryptedMessage = $message[0];
	$portNo = $message[1];
	//echo $messagesRecv . "\n";

	// AES Keys File
	$keys = file_get_contents('chatData/'.$portNo.'keys.json');
	$keys = json_decode($keys, true);
	$AESkey = $keys['key'];
	$AESiv = $keys['iv'];

	$decryptedMessage = openssl_decrypt($encryptedMessage, 'aes-256-cbc', $AESkey, 0, $AESiv);
	//echo $decryptedMessage . "\n";
	if (explode("&", explode("-", $decryptedMessage)[1])[1] == "*.addUser.*") 
	{
		//echo "Adding\n";
		$userData = file_get_contents('chatData/'.$portNo.'data.json');
		$userData = json_decode($userData, true);
		$ips = explode(" ", $userData['ips']);
		$ipArrayFromMessage = explode("," , explode("&", explode("-", $decryptedMessage)[1])[2]);
		for ($i=0; $i < sizeof($ipArrayFromMessage); $i++) 
		{ 
			array_push($ips, $ipArrayFromMessage[$i]);
		}
		$ipsArrayImploded = implode(" ", $ips);
		$userData['ips'] = $ipsArrayImploded;
		$jsonDataEncoded = json_encode($userData);
		file_put_contents('chatData/'.$portNo.'data.json', $jsonDataEncoded);

	} elseif(explode("&", explode("-", $decryptedMessage)[1])[1] == "*.remUser.*") 
	{
		//echo "Deleting\n";
		$userData = file_get_contents('chatData/'.$portNo.'data.json');
		$userData = json_decode($userData, true);
		$ips = explode(" ", $userData['ips']);

		$ipsArrayJavascript = explode("," , explode("&", explode("-", $decryptedMessage)[1])[2]);;
		$ips2 = $ipsArrayJavascript;
		$newArray = array_merge($ipsArrayJavascript, $ips);
		
		for ($i=0; $i < sizeof($ipsArrayJavascript); $i++) 
		{ 
			foreach (array_keys($newArray, $ipsArrayJavascript[$i]) as $key) 
			{
				unset($newArray[$key]);
			}

			if ($ipsArrayJavascript[$i] == file_get_contents("../../ip.txt")) 
			{
				exec('rm -P chatData/' . $portNo . 'data.json');
				exec('rm -P chatData/' . $portNo . 'keys.json');
			}

		}

		$userData['ips'] = trim(implode(" ", $newArray));
		$jsonDataEncoded = json_encode($userData);
		file_put_contents('chatData/'.$deleteUserIPsID.'data.json', $jsonDataEncoded);

	} else
	{
		$messageFile = fopen('chatData/'.$portNo.'message.txt', 'a');
		fwrite($messageFile, $decryptedMessage);
		fclose($messageFile);
	}


	$defaultMessageID = file_get_contents('default.txt');

	$notFile = file_get_contents('not.txt');
	$notFileArray = explode("\n", $notFile);
	$numberToBeAdded = explode(" ", exec('cat not.txt | grep ' . $portNo));
	if ($portNo == $defaultMessageID) {
		continue;
	} else
	{
		$number = intval($numberToBeAdded[1]) + 1;
	}
	$reAttachedNewLine = $numberToBeAdded[0] . " " . $number;
	$command = exec('cat not.txt | grep ' . $portNo);	
	system('sed -i -e "s/'.exec('cat not.txt | grep ' . $portNo).'/'.$reAttachedNewLine.'/g" not.txt');
}


?>