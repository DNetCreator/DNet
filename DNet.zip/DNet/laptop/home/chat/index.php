<?php

// --------------------Variables for Login--------------------
session_start();
error_reporting(0);

if (isset($_SESSION['user'])) 
{
} else 
{
	die(header('Location: /login'));
}

$type = $_POST['type'];
if (isset($type)) 
{
	if ($type == 'send_message_end') {
		system('rm -P chatData.json');
		$file = fopen('chatData.json', 'wb');
		$jsonData->type = 'send_message_end';
		$jsonDataEncoded = json_encode($jsonData);
		fwrite($file, $jsonDataEncoded);
		fclose($file);
	}

}

$color = file_get_contents("../../userData/".$_SESSION['user']."/settings.json");
if (file_exists("../../userData/".$_SESSION['user']."/settings.json")) 
{
	$color = json_decode($color, true);
	$color = $color['color'];
} else
{
	$color = 'rgb(202,0,0)';
}

$font = file_get_contents("../../userData/".$_SESSION['user']."/overallColor.json");
$font = json_decode($font, true);
$font = $font['color'];

system("cd ../users_online; php send.php " . $_SESSION['user'] . " online &");
#system("../../../bin/checkStatus");
system("cd ../users_online; php status.php");
// --------------------Variables for Login--------------------

$contact_username = $_POST['contact_username'];
$contact_ipAddress = $_POST['contact_ipAddress'];
$port = $_POST['contact_sessionID'];
if (isset($contact_username) && isset($contact_ipAddress)) 
{		
	$contacts_txt = fopen("users.txt", 'a');
	$port = rand(1100, 65000);

	$contact_username = str_replace("'", "_", $contact_username);
	$contact_username = str_replace('"', "_", $contact_username);

	$format = $contact_username.'-'.$contact_ipAddress.'-'.$port."|";
	fwrite($contacts_txt, $format);
	fclose($contacts_txt);

	system("touch chatData/". $port."message.json");
	system('touch chatData/'.$port.'message.txt');

	// Port Number File
	$portNo = fopen('portNo.json', 'wb');
	$jsonData->port = $port;
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($portNo, $jsonDataEncoded);
	fclose($portNo);

	$file = fopen("chatData/".$port.'data.json', 'wb');
	$jsonData->ips = trim($contact_ipAddress);
	$jsonData->initiator = file_get_contents("../../ip.txt");
	$jsonData->port = $port;
	$jsonData->username = $_SESSION['user'];
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($file, $jsonDataEncoded);
	fclose($file);
	system("php sendNotification.php " . $port);
	system("open ../../../bin/chatRecv");

	$file = fopen('not.txt', 'a');
	fwrite($file, $port." "."0\n");
	fclose($file);

}

$contact_username2 = $_POST['contact_username2'];
$contact_ipAddress2 = $_POST['contact_ipAddress2'];
$contact_sessionID2 = $_POST['contact_sessionID2'];
$contact_initiator = $_POST['contact_initiator'];
if (isset($contact_username2) && isset($contact_ipAddress2) && isset($contact_sessionID2))
{		
	$contacts_txt2 = fopen("users.txt", 'a');
	system('touch chatData/'.$contact_sessionID2.'message.txt');
	system('touch chatData/'.$contact_sessionID2.'message.json');
	$contact_username2 = str_replace("'", "_", $contact_username2);
	$contact_username2 = str_replace('"', "_", $contact_username2);
	$format2 = $contact_username2.'-'.$contact_ipAddress2.'-'.$contact_sessionID2."|";
	fwrite($contacts_txt2, $format2);
	fclose($contacts_txt2);

	$portNo = fopen('portNo.json', 'wb');
	$jsonData->port = $contact_sessionID2;
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($portNo, $jsonDataEncoded);
	fclose($portNo);

	$file2 = fopen('chatData/'.$contact_sessionID2.'data.json', 'wb');
	$file3 = fopen('data.json', 'wb');
	$jsonData->ips = trim($contact_ipAddress2);
	$jsonData->port = trim((int)$contact_sessionID2);
	$jsonData->initiator = trim($contact_initiator);
	$jsonData->username = $_SESSION['user'];
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($file2, $jsonDataEncoded);
	fwrite($file3, $jsonDataEncoded);
	fclose($file2);
	fclose($file3);
	system("open ../../../bin/chatSend");

	$file = fopen('not.txt', 'a');
	fwrite($file, $contact_sessionID2." "."0\n");
	fclose($file);

}

$sendFileData = $_POST['sendFileData'];
if (isset($sendFileData)) 
{
	$sendFileData = explode('-', $sendFileData);
	$type = $sendFileData[0];
	$ipAddress = $sendFileData[1];

	$fileJson = fopen('../file_sharing/sendFileData.json', 'wb');
	$jsonData->type = $type;

	$jsonData->ipAddress = $ipAddress;
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($fileJson, $jsonDataEncoded);
	fclose($fileJson);
}


$default = $_POST['default'];
if (isset($default)) 
{
	$file = fopen('default.txt', 'wb');
	fwrite($file, $default);
	fclose($file);

	$notFile = file_get_contents('not.txt');
	$notFileArray = explode("\n", $notFile);
	$numberToBeAdded = explode(" ", exec('cat not.txt | grep ' . $default));
	$number = 0;
	$reAttachedNewLine = $numberToBeAdded[0] . " " . $number;
	$command = exec('cat not.txt | grep ' . $default);	
	system('sed -i -e "s/'.exec('cat not.txt | grep ' . $default).'/'.$reAttachedNewLine.'/g" not.txt');


}

?>

<!DOCTYPE html>
<html>
<head>
	<title>DNet | Chat</title>
	<link rel="shortcut icon" type="image/png" href="/icons/logo.png/">
	<link rel="stylesheet" type="text/css" href="/home/chat/index.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
</head>
<body>

	<div class="main">

		<!-- Header -->
		<div class="header" style="background-color: <?php echo $color?>">
			<img onclick="showSidebar()" id="left_ham" src="../../icons/hamburger_lines.png">
			<img onclick="showNotifications()" id="right_ham" src="../../icons/hamburger_lines.png">
			<p style="color: <?php echo $font?>">Chat</p>
		</div>

		<!-- Toggle Sidebar Button -->
		<script src="/dependencies/jquery.js"></script>
		<script type="text/javascript">

			function showSidebar()
			{
				if($(".sidebar").css("display") == 'block')
				{
					$(".sidebar").css("display", "none");
				} else if ($(".sidebar").css("display") == 'none')
				{
					$(".sidebar").css("display", "block");
				}
			}
			function showNotifications()
			{
				if($(".notifications").css("display") == 'block')
				{
					$(".notifications").css("display", "none");
				} else if ($(".notifications").css("display") == 'none')
				{
					$(".notifications").css("display", "block");
				}
			}
			$(document).ready(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						//console.log(dataArray[0].split("\t")[0]);
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+' - '+dataArray[i].split("\t")[1]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+' - '+dataArray[i].split("\t")[1]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			}, 5000);
			$(document).ready(function() {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--)
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			}, 5000);

		</script>

		<!-- Sidebar Menu -->
		<div class="sidebar">
			
			<!-- User Section -->
			<div id="sidebarItem0-1" style="padding: 5%">
				<a href="/home"><img src="/icons/logo.png">
				<p><?php echo $_SESSION['user'] ?></p><br></a>
			</div>
			<hr>
			
			<!-- Main Section -->
			<a href="/home/chat"><div id="sidebarItem1-1" style="padding: 5%; background-color: <?php echo $color?>">
				<p>Chat</p>
			</div></a>
			<a href="/home/file_sharing"><div id="sidebarItem1-2" style="padding: 5%;">
				<p>File Sharing</p>
			</div></a>
			<hr>

			<!-- Contacts -->
			<a href="/home/contacts"><div id="sidebarItem2-1" style="padding: 5%">
				<p>Contacts</p>
			</div></a>
			<hr>

			<!-- Extras Section -->
			<a href="/home/users_online"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Online Users</p>
			</div></a>
			<a href="/home/settings"><div id="sidebarItem3-3" style="padding: 5%;">
				<p>Settings</p>
			</div></a>
			<hr>

			<!-- Help Section -->
			<a href="/home/chat/help.txt"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Help</p>
			</div></a>
			<hr>

			<!-- Logout -->
			<a href="/home/logout"><div id="sidebarItem4-1" style="padding: 5%;">
				<p>Logout</p>
			</div></a>

		</div>

		<div id="settingsDiv" style="background-color: <?php echo $color ?>"></div>

		<div id="addNewIP" style="background-color: <?php echo $color ?>"></div>

		<div id="changeChatName" style="background-color: <?php echo $color ?>"></div>

		<div id="deleteUserIPs" style="background-color: <?php echo $color ?>"></div>

		<script type="text/javascript">
			<?php

				$IPs = $_POST['addIPArray'];
				$newUsersID = $_POST['newUsersID'];
				if (isset($IPs) && isset($newUsersID)) 
				{
					$userData = file_get_contents('chatData/'.$newUsersID.'data.json');
					$userData = json_decode($userData, true);
					$ips = explode(" ", $userData['ips']);
					$ipsArrayJavascript = explode(',', $IPs);

					$newArray = array_merge($ipsArrayJavascript, $ips); // Works up to here
					$newData = implode(" ", $newArray);
					$userData['ips'] = $newData;
					$jsonDataEncoded = json_encode($userData);
					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						file_put_contents('chatData/'.$newUsersID.'data.json', $jsonDataEncoded);
					}
					$format = '&*.addUser.*&'.$IPs;

					$encryptionKeys = file_get_contents('chatData/'.$newUsersID.'keys.json');
					$encryptionKeys = json_decode($encryptionKeys, true);
					$key = $encryptionKeys['key'];
					$iv = $encryptionKeys['iv'];

					$socketTmp = socket_create(AF_INET, SOCK_DGRAM, 0);
					$msg = $_SESSION['user'] . "-" . " <<< You have been added to the chat >>> " . "-" . date("h:i A")."|";
					$encryptedMsg = openssl_encrypt($msg, 'aes-256-cbc', $key, 0, $iv);

					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						for ($j=0; $j < sizeof($ipsArrayJavascript); $j++) 
						{ 
							socket_sendto($socketTmp, $encryptedMsg.".".$newUsersID, strlen($encryptedMsg.".".$newUsersID), 0, $ipsArrayJavascript[$j], 6782);
						}
					}

					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						system("php UDPSend.php " . "'" . $format . "'" . " " . $newUsersID);
					}
					$file = fopen('addUsers.json', 'wb');
					$jsonData->ips = str_replace(",", " ", $IPs);
					$jsonData->port = $newUsersID;
					$jsonDataEncoded = json_encode($jsonData);
					fwrite($file, $jsonDataEncoded);
					fclose($file);
					system("php sendNotificationAdd.php " . $newUsersID);
					system("open ../../../bin/chatRecvAddUser");

					$file = fopen('chatData/'.$newUsersID.'message.txt', 'a');
					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						fwrite($file, "You- <<< Users Added: " . str_replace(",", ", ", $IPs) . " >>> -".date("h:i A")."|");
					} else
					{
						fwrite($file, "You- <<< You are not admin >>> -".date("h:i A")."|");
					}
					fclose($file);
					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						$format =  " <<< Users Added: " . str_replace(",", ", ", $IPs) . " >>> ";
						exec("php UDPSend.php " . "'" . $format . "'" . " " . $newUsersID);
					}

				}

				$colors = $_POST['changeUserColorsArray'];
				$changeColorsID = $_POST['changeColorsID'];
				if (isset($colors) && isset($changeColorsID)) 
				{
					$userData = file_get_contents('chatData/'.$changeColorsID.'data.json');
					$userData = json_decode($userData, true);
					$ips = explode(" ", $userData['ips']);
					$colorSettings = explode(',', $colors);

					$originalColors = file_get_contents('chatData/'.$changeColorsID.'settings.txt');
					$originalColors = explode("\n", $originalColors);

					$file = fopen('chatData/'.$changeColorsID.'settings.txt', 'wb');
					for ($i=0; $i < sizeof($ips); $i++) 
					{ 
						if (strlen($colorSettings[$i] >= 0)) {
							fwrite($file, $ips[$i]."-".$colorSettings[$i]."\n");
						} else if(strlen($colorSettings[$i] == 0))
						{
							fwrite($file, $ips[$i]."-".explode("-", $originalColors[$i])[1]."\n");
						}
					}
					fclose($file);
				}

				$newChatName = $_POST['newName'];
				$changeNameID = $_POST['changeNameID'];
				if (isset($newChatName) && isset($changeNameID)) 
				{
					$userFile = file_get_contents('users.txt');
					$userFileData = explode("|", $userFile);
					$newArray = array();
					for ($i=0; $i < sizeof($userFileData); $i++) 
					{ 
						//$data = strpos($changeNameID, $userFileData[$i]);
						if (explode('-', $userFileData[$i])[2] == $changeNameID) 
						{
							$array = explode('-', $userFileData[$i]);
							$array[0] = $newChatName;
							$arrayNew = implode('-', $array);
							array_push($newArray, $arrayNew);
						} else
						{
							array_push($newArray, $userFileData[$i]);
						}
					}
					file_put_contents('users.txt', implode("|", $newArray));

				}

				$deleteUserIPs = $_POST['usersToDelete'];
				$deleteUserIPsID = $_POST['deleteUserID'];

				if (isset($deleteUserIPs) && isset($deleteUserIPsID)) 
				{
					$userData = file_get_contents('chatData/'.$deleteUserIPsID.'data.json');
					$userData = json_decode($userData, true);

					$ips = explode(" ", $userData['ips']);

					// IPs TO BE DELETED IN ARRAY
					$ipsArrayJavascript = explode(',', $deleteUserIPs);
					$ips2 = $ipsArrayJavascript;
					$newArray = array_merge($ipsArrayJavascript, $ips);
					
					for ($i=0; $i < sizeof($ipsArrayJavascript); $i++) 
					{ 
						foreach (array_keys($newArray, $ipsArrayJavascript[$i]) as $key) 
						{
    						unset($newArray[$key]);
						}

					}

					$encryptionKeys = file_get_contents('chatData/'.$deleteUserIPsID.'keys.json');
					$encryptionKeys = json_decode($encryptionKeys, true);
					$key = $encryptionKeys['key'];
					$iv = $encryptionKeys['iv'];

					$socketTmp = socket_create(AF_INET, SOCK_DGRAM, 0);
					$msg = $_SESSION['user'] . "-" . " <<< You have been removed from the chat >>> " . "-" . date("h:i A")."|";
					$encryptedMsg = openssl_encrypt($msg, 'aes-256-cbc', $key, 0, $iv);

					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						for ($j=0; $j < sizeof($ips2); $j++) 
						{ 
							socket_sendto($socketTmp, $encryptedMsg.".".$deleteUserIPsID, strlen($encryptedMsg.".".$deleteUserIPsID), 0, $ips2[$j], 6782);
						}
					}

					$format = '&*.remUser.*&'.implode(',', $ips2);
					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						system("php UDPSend.php " . "'" . $format . "'" . " " . $deleteUserIPsID);
					}

					$userData['ips'] = trim(implode(" ", $newArray));
					$jsonDataEncoded = json_encode($userData);
					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						file_put_contents('chatData/'.$deleteUserIPsID.'data.json', $jsonDataEncoded);
					}

					$file = fopen('chatData/'.$deleteUserIPsID.'message.txt', 'a');
					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						fwrite($file, "You- <<< ".implode(', ', $ips2) . " removed. >>> -".date("h:i A")."|");
					} else
					{
						fwrite($file, "You- <<< You are not admin >>> -".date("h:i A")."|");
					}
					
					fclose($file);

					if ($userData['initiator'] == file_get_contents("../../ip.txt")) 
					{
						system("php UDPSend.php " . "' <<< " . implode(',', $ips2) . ' removed. >>> ' . "'" . " " . $deleteUserIPsID);
					}

				}

			?>
			function addUsers(messageID)
			{
				var inputs = $(".newIP");
				var array = [];
				for(var i = 0; i < inputs.length; i++){
				    array.push($(inputs[i]).val())
				}

				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/chat/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "addIPArray=" + encodeURIComponent(array) + "&newUsersID=" + encodeURIComponent(messageID);
				xhttp.send(data);
				$("#addNewIP").hide();
				$(".contacts_list").css("opacity", "1");			
			}

			function changeUserColors(messageID)
			{
				var inputs = $(".colorChange");
				var array = [];
				for(var i = 0; i < inputs.length; i++)
				{
				    array.push($(inputs[i]).val());
				}
				
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/chat/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "changeUserColorsArray=" + encodeURIComponent(array) + "&changeColorsID=" + encodeURIComponent(messageID);
				xhttp.send(data);
				$("#settingsDiv").hide();
				$(".contacts_list").css("opacity", "1");
				setTimeout(function(){document.location.href = "/home/chat/"}, 300);
			}

			function changeChatName2(messageID)
			{
				var newName = document.getElementById('name').value;
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/chat/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "newName=" + encodeURIComponent(newName) + "&changeNameID=" + encodeURIComponent(messageID);
				xhttp.send(data);
				$("#changeChatName").hide();
				$(".contacts_list").css("opacity", "1");
				setTimeout(function(){document.location.href = "/home/chat/"}, 300);

			}

			function deleteUserIPs2(messageID)
			{
				var checkedBoxes = document.querySelectorAll('input[name=checkbox]:checked');
				var array = [];
				for(var i = 0; i < checkedBoxes.length; i++)
				{
				    array.push($(checkedBoxes[i]).val());
				}
				//console.log(array);
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/chat/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "usersToDelete=" + encodeURIComponent(array) + "&deleteUserID=" + encodeURIComponent(messageID);
				xhttp.send(data);
				$("#deleteUserIPs").hide();
				$(".contacts_list").css("opacity", "1");
			}

			function cancelChangeName()
			{
				$("#changeChatName").hide();
				$(".contacts_list").css("opacity", "1");
				$("#name").val() = "";
			}

			function cancelAddUsers()
			{
				$("#addNewIP").hide();
				$(".contacts_list").css("opacity", "1");
				$(".newIP").val() = "";
			}

			function cancelSettingsDiv()
			{
				$("#settingsDiv").hide();
				$(".contacts_list").css("opacity", "1");
				$(".colorChange").val() = "";
			}

			function cancelDeleteUserIP()
			{
				$("#deleteUserIPs").hide();
				$(".contacts_list").css("opacity", "1");
			}
		</script>

		<div id="settingChoose" style="background-color: <?php echo $color ?>"></div>

		<?php

		$deleteUserID = $_POST['deleteUserID'];
		$toDeleteID = $_POST['IDforDeletion'];
		if (isset($deleteUserID) && isset($toDeleteID)) 
		{
			$file = fopen("users.txt", 'wb');
			fwrite($file, $deleteUserID);
			fclose($file);
			system('rm chatData/'.$toDeleteID.'data.json chatData/'.$toDeleteID.'keys.json chatData/'.$toDeleteID.'message.json chatData/'.$toDeleteID.'message.txt chatData/'.$toDeleteID.'settings.txt');

			$notFile = file_get_contents('not.txt');
			$IDtoDelete = $toDeleteID;

			$notFileArray = explode("\n", $notFile);

			$newArray = array();

			for ($i=0; $i < sizeof($notFileArray); $i++) 
			{ 
				$tempLine = explode(" ", $notFileArray[$i]);
				$id = $tempLine[0];
				$notNum = $tempLine[1];

				if ($id == $IDtoDelete) 
				{
					array_push($newArray, $id);
					array_push($newArray, $notNum);
					break;
				}
			}

			$lineToReplace = implode(" ", $newArray);
			system('grep -v "'.$lineToReplace.'" not.txt > not2.txt');
			sleep(0.5);
			system('cat not2.txt > not.txt');
			system('rm -P not2.txt');
			header("Location: /home/chat/index.php");
		}

		$IDclearChat = $_POST['IDclearChat'];
		$clearChat = $_POST['deleteChat'];

		if (isset($IDclearChat) && isset($clearChat)) 
		{
			if ($clearChat == 'deleteChat') 
			{
				system(':>| chatData/' . $IDclearChat . 'message.txt');
			}
		}

		?>

		<script type="text/javascript">

			function deleteUserIPs()
			{
				$(".contacts_list").css("opacity", "0.3");
				$("#settingChoose").hide();	
				$("#deleteUserIPs").show();
			}

			function changeColors(ID)
			{
				$(".contacts_list").css("opacity", "0.3");
				$("#settingChoose").hide();	
				$("#settingsDiv").show();
			}

			function addUserIPs(ID)
			{
				$(".contacts_list").css("opacity", "0.3");
				$("#settingChoose").hide();	
				$("#addNewIP").show();
			}

			function clearChat(ID)
			{
				//console.log("ID in Clear Chat: " + ID);
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/chat/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "IDclearChat=" + encodeURIComponent(ID) + "&deleteChat=deleteChat";
				xhttp.send(data);	
				console.log(data);
				$("#settingChoose").hide();	
				$(".contacts_list").css("opacity", "1");

			}

			function deleteUser(ID, username, ipAddress)
			{
				if (confirm("You will not recieve messages from this chat forever. Are you sure?")) 
				{
					//console.log(ID, username, ipAddress);
					var xhttp = new XMLHttpRequest();
					xhttp.onreadystatechange = function() 
					{
						if (this.readyState == 4 && this.status == 200) 
						{
							//console.log("ID: " + ID);
							//console.log("Username: " + username);
							//console.log("IP Address: " + ipAddress);
							var data = this.responseText;
							//console.log(data);
							var userDeleted = data.replace(username + "-" + ipAddress + "-" + ID + "|", "")
							//console.log(userDeleted);
							var xhttp = new XMLHttpRequest();
							xhttp.open("POST", "/home/chat/index.php", true);
							xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
							var data = "deleteUserID=" + userDeleted + "&IDforDeletion=" + ID;
							//console.log(data);
							xhttp.send(data);
						}
					};
					xhttp.open("POST", "/home/chat/users.txt", true);
					xhttp.send();
					setTimeout(function(){ document.location.href = '/home/chat/index.php'; }, 400);
					$("#settingChoose").hide();	
					$(".contacts_list").css("opacity", "1");
				} else 
				{
					document.location.href = '/home/chat/index.php';
				}
			}
		</script>

		<script type="text/javascript">


			function addNewIP()
			{
				txt1 = '<input class="newIP" type="text" name="newIP[]" placeholder="Type IP Address">';
				$("#ips").append(txt1);
			}

			<?php

			$ID = $_POST['ID'];
			$SettingStatus = $_POST['settings'];
			$usernameID = $_POST['usernameID'];
			$ipAddressID = $_POST['ipAddressID'];

			if (isset($ID) && isset($SettingStatus) && isset($usernameID) && isset($ipAddressID)) 
			{
				$file = fopen('settings.txt', 'wb');
				fwrite($file, $ID . "\n" . $SettingStatus . "\n" . $usernameID . "\n" . $ipAddressID);
				fclose($file);
			}


			?>

			function showSettingsDiv(messageID, username, ipAddress)
			{
				var settings = true;
				var xhttp = new XMLHttpRequest();
				//console.log(messageID, username, ipAddress);
				xhttp.open("POST", "/home/chat/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "ID=" + encodeURIComponent(messageID) + "&settings=" + encodeURIComponent(settings) + "&usernameID=" + encodeURIComponent(username)+ "&ipAddressID=" + encodeURIComponent(ipAddress);
				xhttp.send(data);
				//document.getElementById("settingChoose").style.display = "block";
				//$(".contacts_list").css("opacity", "0.3");
			}

			function changeChatName(chatName)
			{
				$(".contacts_list").css("opacity", "0.3");
				$("#settingChoose").hide();	
				$("#changeChatName").show();
			}

		</script>

		<!-- Contacts -->
		<div class="chat">

			<!-- Main Features -->

			<div class="contacts_list" style="background-color: <?php echo $color?>">

				<div id="top_panel">
					<button type="button" onclick="addNewPerson()">Start a New Chat</button>
					<button type="button" onclick="connect()">Connect to User</button>
				</div>
				
				<div class="left_side" style="border-right-color: <?php echo $color?>"></div>

				
				<div id="right_side" class="right_side" style="bottom: 0; border-left-color: <?php echo $color?>"></div>

				<script src="/dependencies/jquery.js"></script>
				<?php
					// SEND MESSAGES THROUGH TEXTAREA
					$message = $_POST['message'];
					$sessionID = $_POST['messageID'];
					if (isset($message))
					{
						$file = fopen('chatData/'.$sessionID.'message.json', 'wb');
						$message = explode("\n", $message);
						$jsonData->message = $message[0];
						$jsonDataEncoded = json_encode($jsonData);
						fwrite($file, $jsonDataEncoded);
						fclose($file);

						$messageFile = fopen('chatData/'.$sessionID.'message.txt', 'a');
						date_default_timezone_set("Asia/Dubai");
						$format = 'You'.'-'.str_replace("-", "~", str_replace("\"", "'", $message[0])).'-'.date("h:i A")."|";
						fwrite($messageFile, $format);
						fclose($messageFile);

						system("php UDPSend.php " . "\"" . str_replace("-", "~", str_replace("\"", "'", $message[0])) . "\"" . " " . $sessionID);
					} 

				?>
				<script type="text/javascript">
					// SEND MESSAGE PROCESSING
					function sendMessage(event, messageID)
					{
						var key = event.keyCode;
						message = document.getElementById('textarea');
						if (key == 13) 
						{
							var xhttp = new XMLHttpRequest();
							//console.log(message.value);
							//console.log(messageID);
							xhttp.open("POST", "/home/chat/index.php", true);
							xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
							var data = "message=" + encodeURIComponent(message.value) + "&messageID=" + encodeURIComponent(messageID);
							xhttp.send(data);
							document.getElementById('textarea').value = '';
						}
					}
				</script>
				<script type="text/javascript">

				<?php

				$delete = $_POST['delete'];
				if (isset($delete)) {
					system('rm settings.txt');
				}

				?>

				$(document).ready(function()
				{
					$.getJSON('chatData.json', function(results)
					{
						var type = results.type;
						// var username = results.username;
						var ipAddress = results.ipAddress;
						//console.log(type == 'send_message');
						if (type == 'send_message') 
						{
							$(".addPerson").show();
							document.getElementById('contact_ipAddress').value = ipAddress; // ------------------------------------------------
							var xhttp = new XMLHttpRequest();
							xhttp.open("POST", "/home/chat/index.php", true);
							xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
							var data = "type=send_message_end";
							//console.log(data);
							xhttp.send(data);
						}
					});
					var xhttp = new XMLHttpRequest();
					xhttp.onreadystatechange = function() 
					{
						if (this.readyState == 4 && this.status == 200)
						{
							defaultSessionID = this.responseText;
							var xhttp = new XMLHttpRequest();
							xhttp.onreadystatechange = function()
							{
								if (this.readyState == 4 && this.status == 200)
								{
									var data = this.responseText;
									var name_and_IP = data.split("|");
									//console.log(name_and_IP);
									for (var i = 0; i < name_and_IP.length-1; i++) 
									{
										var name_and_IPs = name_and_IP[i];
										var contact_information = name_and_IPs.split("-");
										var username = contact_information[0];
										var ipAddress = contact_information[1];
										var messageID = contact_information[2];

										//console.log(username, ipAddress, messageID);

										var txt1 = '<div id="peerson'+messageID+'" style="padding: 2%; border-bottom: 2px solid white; padding: 7px;" onclick="showPersonMessages(\'' + messageID + '\'); setDefault(\'' + messageID + '\')"> \
										<p style="font-size: 17px; float: left; margin-top: 9px;">'+ username +'</p> \
										<a href="#"><img style="width: 25px; margin-top: 5px;" id="settings" onclick="showSettingsDiv(\'' + messageID + '\', \'' + username + '\', \'' + ipAddress + '\')" src="../../icons/settings.png"  title="Change Chat Settings"></a> \
										<a href="#"><img style="width: 25px; margin-top: 5px;" id="file" onclick="sendFileToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/white_file.png" title="Send File to this User"></a><br> \
										<p id="notificationsNumber'+messageID+'" style="color: white; float: right; margin-right: 10px; margin-top: -9px; font-size: 18px;"></p> \
										<br> \
										</div>';
										$(".left_side").append(txt1);
									}
									$('#peerson'+defaultSessionID).css("background-color", "<?php echo $color?>");
									var xhttp = new XMLHttpRequest();
									xhttp.onreadystatechange = function() 
									{
										if (this.readyState == 4 && this.status == 200)
										{
											var settingsData = this.responseText;
											var settings = settingsData.split("\n");
											//console.log(settings);
											var ID = settings[0];
											var settingsStatus = settings[1];
											var username = settings[2];
											var ipAddress = settings[3];
											//console.log(ID);
											//console.log(settingsStatus);
											if (settingsStatus == 'true') 
											{
												showSettings(ID);
												var xhttp = new XMLHttpRequest();
												xhttp.open("POST", "/home/chat/index.php", true);
												xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
												var data = "delete=delete";
												xhttp.send(data);
												var settingsDivInfo = 
													'<button onclick="changeColors(\'' + ID + '\')">Change User Colors</button> \
													<button onclick="changeChatName(\''+messageID+'\')">Change Name</button><br> \
													<button onclick="addUserIPs(\'' + ID + '\')">Add Users</button> \
													<button onclick="deleteUserIPs()">Remove Users</button><br> \
													<button onclick="clearChat(\'' + ID + '\');" >Clear Chat</button> \
													<button onclick="deleteUser(\'' + ID + '\', \'' + username + '\', \'' + ipAddress + '\')" >Delete Chat</button><br> \
													<button style="width: 98%; margin-top: 5px; border-radius: 20px 20px 20px 20px" onclick="$(\'#settingChoose\').hide(); $(\'.contacts_list\').css(\'opacity\', \'1\');">Cancel</button>'
												$('#settingChoose').append(settingsDivInfo);

												var addIPsInfo = '<label style="float: left; color: <?php echo $font?>">Add New IPs</label> \
															<a href="#" title="Add User"><img onclick="addNewIP()" id="add_button" src="../../icons/add.png"></a><br><br> \
															<div id="ips"></div> \
															<button onclick="cancelAddUsers()">Cancel</button> \
															<button onclick="addUsers(\'' + ID + '\')">Submit</button>'
												$("#addNewIP").append(addIPsInfo);

												$.getJSON('/home/chat/chatData/'+ID+'data.json', function(results) 
												{
													var ipsVar = results.ips;
													var ipArray = ipsVar.split(" ");
													//console.log(ipArray);

													var xhttp = new XMLHttpRequest();
													xhttp.onreadystatechange = function() 
													{
														if (this.readyState == 4 && this.status == 200)
														{
															var allColorsDone = this.responseText;
															var allColorsDoneArr = allColorsDone.split("\n");

															for (var i = 0; i < ipArray.length; i++) 
															{
																var settingsDivInfoPart1 = '<label style="color: <?php echo $font?>">COLOR: '+ipArray[i]+'</label> \
																	<input class="colorChange" type="text" name="color" placeholder="e.g. #efefef" value='+allColorsDoneArr[i].split("-")[1]+'><br>';
																	$("#settingsDiv").append(settingsDivInfoPart1);
															}

															var settingsDivInfoPart2 = '<button onclick="cancelSettingsDiv()">Cancel</button> \
																<button onclick="changeUserColors(\'' + ID + '\')">Submit</button> \
																<a href="https://www.w3schools.com/colors/colors_picker.asp" target="_blank"><p \style="margin-top: 10px; color: white; font-size: 15px; color: <?php echo $font?>">Open Color Picker</p></a>';
															$("#settingsDiv").append(settingsDivInfoPart2);

														}
													};
													xhttp.open("POST", "/home/chat/chatData/"+ID+"settings.txt", true);
													xhttp.send();
												});

												var changeChatName = '<label style="color: <?php echo $font?>">Change Chat Name</label><br> \
																		<input id="name" type="text" name="newChatName" placeholder="Name">\
																		<button onclick="cancelChangeName()">Cancel</button>\
																		<button onclick="changeChatName2(\''+messageID+'\')">Change Chat Name</button>';
												$("#changeChatName").append(changeChatName);


												$.getJSON('/home/chat/chatData/'+ID+'data.json', function(results) 
												{
													var ipsVar = results.ips;
													var ipArray = ipsVar.split(" ");
													//console.log(ipArray);

													for (var i = 0; i < ipArray.length; i++) 
													{
														if (ipArray[i] != "") 
														{
															var deleteUserIPPart1 = '<input type="checkbox" name="checkbox" value="'+ipArray[i]+'"><p style="color: <?php echo $font?>">'+ipArray[i]+'</p><br>';
															$("#deleteUserIPs").append(deleteUserIPPart1);
														}
													}
													
													var deleteUserIPPart2 = '<button onclick="cancelDeleteUserIP()">Cancel</button><button type="button" onclick="deleteUserIPs2(\'' + ID + '\')">Delete Users</button>';
													$("#deleteUserIPs").append(deleteUserIPPart2);
												});

											}
										}
									};
									xhttp.open("POST", "/home/chat/settings.txt", true);
									xhttp.send();
								}
							};
							showPersonMessages(defaultSessionID);
							xhttp.open("POST", "/home/chat/users.txt", true);
							xhttp.send();
						}
					};
					xhttp.open("POST", "/home/chat/default.txt", true);
					xhttp.send();
				});

				function showSettings(messageID)
				{
					//console.log(messageID);
					document.getElementById('settingChoose').style.display = 'block';
					$(".contacts_list").css("opacity", "0.3");

				}

				function showPersonMessages(messageID)
				{
					var xhttp = new XMLHttpRequest();
					xhttp.onreadystatechange = function() 
					{
						if (this.readyState == 4 && this.status == 200) 
						{
							var data = this.responseText;
							var xhttp = new XMLHttpRequest();
							xhttp.onreadystatechange = function() 
							{
								if (this.readyState == 4 && this.status == 200) 
								{
									var data2 = this.responseText
									var colorArray = data2.split("\n");
									colorArray.pop();																	
									currentColor = "blue";
									currentColorForYou = "yellow";
									var messages = data.split("|");
									$('.right_side').empty();
									for (var i = 0; i < messages.length-1; i++)
									{
										var information = messages[i].split('-');
										for (var j = 0; j < colorArray.length; j++)
										{
											if (colorArray[j].split("-")[0] == information[3]) 
											{
												currentColor = colorArray[j].split("-")[1];
											}

											if (colorArray[j].split("-")[0] == '<?php echo file_get_contents("../../ip.txt")?>') 
											{
												currentColorForYou = colorArray[j].split("-")[1];
											}
										
										}
										if (information[0] == "You") 
										{
											var txt1 = '<div style="border-right: 12px solid '+currentColorForYou+';" id="msg"> \
														<label>'+information[0]+'</label> \
														<p id="time2">'+information[2]+'</p><br><br> \
														<p>'+information[1]+'</p><br> \
													</div>'
											$(".right_side").append(txt1);
										} else if (information[0] != "You") 
										{
											var txt1 = '<div style="border-left: 12px solid '+currentColor+';" id="msg2"> \
														<label>'+information[0]+'</label> \
														<p id="time">'+information[2]+'</p><br><br> \
														<p>'+information[1]+'</p><br> \
													</div>'
											$(".right_side").append(txt1);
										}
									}

									var xhttp1 = new XMLHttpRequest();
									xhttp1.onreadystatechange = function() 
									{
										if (this.readyState == 4 && this.status == 200) 
										{
											var allData = this.responseText;
											var eachLine = allData.split("\n");
											eachLine.pop();

											<?php $defaultMessageID = file_get_contents('default.txt'); ?>

											for (var m = 0; m < eachLine.length; m++) 
											{
												var tempLine = eachLine[m].split(" ");
												//console.log(eachLine);
												var id = tempLine[0];
												var notNum = tempLine[1];

												$("#notificationsNumber"+id).empty();
												if (notNum != 0) 
												{
													if (id == <?php echo $defaultMessageID ?>) 
													{
														continue
													} else 
													{
														$("#notificationsNumber"+id).append(notNum);
													}
												}
											}
										}
									};
									xhttp1.open("POST", "/home/chat/not.txt", true);
									xhttp1.send();

								}
								scroll = document.querySelector('.right_side')
								scroll.scrollTop = scroll.scrollHeight;
							};
							xhttp.open("POST", "/home/chat/chatData/"+messageID+"settings.txt", true);
							xhttp.send();

							$("#textarea").remove();
							var txt2 = '<textarea style="border-left-color: <?php echo $color?>" id="textarea" onkeyup="sendMessage(event, \'' + messageID + '\')" placeholder="Type Message..."></textarea>'
							$('.contacts_list').append(txt2);
						}
					};
					xhttp.open("POST", "/home/chat/chatData/"+messageID+"message.txt", true);
					xhttp.send();

					setInterval(function()
					{
						div = document.querySelector('.right_side');
						if (div.scrollTop + div.clientHeight == div.scrollHeight ) 
						{
							var goDown = 1;
						} else 
						{
							var goDown = 0;
						}
						//console.log(goDown);
						var xhttp = new XMLHttpRequest();
						xhttp.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								var data = this.responseText;
								var xhttp = new XMLHttpRequest();
								xhttp.onreadystatechange = function() 
								{
									if (this.readyState == 4 && this.status == 200) 
									{
										var data2 = this.responseText
										var colorArray = data2.split("\n");
										colorArray.pop();
										//colorArray[0].split("-")[1];
										
										currentColor = "blue";
										currentColorForYou = "yellow";
										var messages = data.split("|");
										$('.right_side').empty();
										for (var i = 0; i < messages.length-1; i++)
										{
											var information = messages[i].split('-');
											for (var j = 0; j < colorArray.length; j++)
											{
												if (colorArray[j].split("-")[0] == information[3]) 
												{
													currentColor = colorArray[j].split("-")[1];
												}	
												if (colorArray[j].split("-")[0] == '<?php echo file_get_contents("../../ip.txt") ?>') 
												{
													currentColorForYou = colorArray[j].split("-")[1];
												}										
											}
											if (information[0] == "You") 
											{
												var txt1 = '<div style="border-right: 12px solid '+currentColorForYou+';" id="msg"> \
															<label>'+information[0]+'</label> \
															<p id="time2">'+information[2]+'</p><br><br> \
															<p>'+information[1]+'</p><br> \
														</div>'
												$(".right_side").append(txt1);
											} else if (information[0] != "You") 
											{
												var txt1 = '<div style="border-left: 12px solid '+currentColor+';" id="msg2"> \
															<label>'+information[0]+'</label> \
															<p id="time">'+information[2]+'</p><br><br> \
															<p>'+information[1]+'</p><br> \
														</div>'
												$(".right_side").append(txt1);
											}
										}
									}

								};
								xhttp.open("POST", "/home/chat/chatData/"+messageID+"settings.txt", true);
								xhttp.send();
							}
						};
						if (goDown == 1) 
						{
							div = document.querySelector('.right_side');
							//console.log("Going Down");
							setTimeout(function(){div.scrollTop = div.scrollHeight}, 100);
							
						}
						xhttp.open("POST", "/home/chat/chatData/"+messageID+"message.txt", true);
						xhttp.send();

						var xhttp1 = new XMLHttpRequest();
						xhttp1.onreadystatechange = function() 
						{
							if (this.readyState == 4 && this.status == 200) 
							{
								var allData = this.responseText;
								var eachLine = allData.split("\n");
								eachLine.pop();

								<?php $defaultMessageID = file_get_contents('default.txt'); ?>

								for (var m = 0; m < eachLine.length; m++) 
								{
									var tempLine = eachLine[m].split(" ");
									//console.log(eachLine);
									var id = tempLine[0];
									var notNum = tempLine[1];

									$("#notificationsNumber"+id).empty();
									if (notNum != 0) 
									{
										if (id == <?php echo $defaultMessageID ?>) 
										{
											continue
										} else 
										{
											$("#notificationsNumber"+id).append(notNum);
										}
									}
								}
							}
						};
						xhttp1.open("POST", "/home/chat/not.txt", true);
						xhttp1.send();

					}, 2000);
				}

				function savePersonToFile()
				{
					$(".addPerson").hide();
					$(".contacts_list").css("opacity", "1");
					var contact_username = document.getElementById('contact_username');
					var contact_ipAddress = document.getElementById('contact_ipAddress');
					var contact_sessionID = document.getElementById('contact_sessionID');
					var xhttp = new XMLHttpRequest();
					xhttp.open("POST", "/home/chat/index.php", true);
					xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					var data = "contact_username=" + encodeURIComponent(contact_username.value) + "&contact_ipAddress=" + encodeURIComponent(contact_ipAddress.value) + "&contact_sessionID=" + encodeURIComponent(contact_sessionID.value);

					if (contact_username.value.length > 0 && contact_ipAddress.value.length > 0 && contact_sessionID.value.length) 
					{
						username = contact_username.value;
						ipAddress = contact_ipAddress.value;
						messageID = contact_sessionID.value;

						xhttp.send(data);

						var txt1 = '<div id="peerson'+messageID+'" style="padding: 2%; border-bottom: 2px solid white; padding: 7px;" onclick="showPersonMessages(\'' + messageID + '\'); setDefault(\'' + messageID + '\')"> \
										<p style="font-size: 17px; float: left; margin-top: 9px;">'+ username +'</p> \
										<a href="#"><img style="width: 25px; margin-top: 5px;" id="settings" onclick="showSettingsDiv(\'' + messageID + '\')" src="../../icons/settings.png"  title="Change Chat Settings"></a> \
										<a href="#"><img style="width: 25px; margin-top: 5px;" id="file" onclick="sendFileToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/white_file.png" title="Send File to this User"></a><br> \
										<br> \
										</div>';
						$(".left_side").append(txt1);
					} else 
					{
						alert("Fill all fields");
					}			
					
					document.getElementById('contact_username').value = "";
					document.getElementById('contact_ipAddress').value = "";
					setTimeout(function(){document.location.href = "/home/chat/index.php"}, 500);
	
				}

				function sendFileToUser(username, ipAddress)
				{
					//console.log("sendFileToUser: " + username + ", " + ipAddress);
					// The data is taken. 

					// The type is Sending_File
					var type = 'send_file';
					// Type is saved along with data
					var data = type + '-' + ipAddress
					// XML Request sends to PHP
					var xhttp = new XMLHttpRequest();
					xhttp.open("POST", "/home/chat/index.php", true);
					xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					var data = "sendFileData=" + data;
					//console.log(data);
					xhttp.send(data);
					setTimeout(function(){ document.location.href = '/home/file_sharing/index.php'; }, 98);
					// PHP makes JSON file with data inside it

					// The Page will redirect
				}

				// SAME THING BUT INSTEAD YOU'RE CONNECTING TO USEr
				function savePersonToFile2()
				{
					$(".connectToUser").hide();
					$(".contacts_list").css("opacity", "1");
					var contact_username2 = document.getElementById('contact_username2');
					var contact_ipAddress2 = document.getElementById('contact_ipAddress2');
					var contact_sessionID2 = document.getElementById('contact_sessionID2');
					var contact_initiator = document.getElementById('contact_initiator');
					var xhttp = new XMLHttpRequest();
					xhttp.open("POST", "/home/chat/index.php", true);
					xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					var data = "contact_username2=" + encodeURIComponent(contact_username2.value) + "&contact_ipAddress2=" + encodeURIComponent(contact_ipAddress2.value) + "&contact_sessionID2=" + encodeURIComponent(contact_sessionID2.value) + "&contact_initiator=" + encodeURIComponent(contact_initiator.value);
					if (contact_username2.value.length > 0 && contact_ipAddress2.value.length > 0 && contact_sessionID2.value.length > 0 && contact_initiator.value.length > 0) 
					{
						username = contact_username2.value;
						ipAddress = contact_ipAddress2.value;
						contact_sessionID2 = contact_sessionID2.value;

						xhttp.send(data);

						var txt1 = '<div id="peerson'+contact_sessionID2+'" style="padding: 2%; border-bottom: 2px solid white; padding: 7px;" onclick="showPersonMessages(\'' + contact_sessionID2 + '\'); setDefault(\'' + contact_sessionID2 + '\')"> \
										<p style="font-size: 17px; float: left; margin-top: 9px;">'+ username +'</p> \
										<a href="#"><img style="width: 25px; margin-top: 5px;" id="settings" onclick="showSettingsDiv(\'' + contact_sessionID2 + '\')" src="../../icons/settings.png"  title="Change Chat Settings"></a> \
										<a href="#"><img style="width: 25px; margin-top: 5px;" id="file" onclick="sendFileToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/white_file.png" title="Send File to this User"></a><br> \
										<br> \
										</div>';
						$(".left_side").append(txt1);
					} else 
					{
						alert("Fill all fields");
					}			
					
					document.getElementById('contact_username2').value = "";
					document.getElementById('contact_ipAddress2').value = "";	
					document.getElementById('contact_sessionID2').value = "";
					document.getElementById('contact_initiator').value = "";
					setTimeout(function(){document.location.href = "/home/chat/index.php"}, 500);
				}

				function setDefault(messageID)
				{
					var xhttp = new XMLHttpRequest();
					xhttp.open("POST", "/home/chat/index.php", true);
					xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					var data = "default=" + messageID;
					//console.log(data);
					xhttp.send(data);
					//document.location.href = "/home/chat/index.php";
					setTimeout(function(){document.location.href = "/home/chat/index.php"}, 500);
				}

				</script>

			</div>

		</div>
		<div class="addPerson" style="background-color: <?php echo $color ?>">
			<input maxlength="12" id="contact_username" type="text" name="name" placeholder="Name"><br>
			<input id="contact_ipAddress" type="text" name="ip" placeholder="IPs">
			<input id="contact_sessionID" style="display: none" type="text" value="<?php echo rand(1100, 65000) ?>" name="sessionID" placeholder="Session ID"><br>
			<button id="cancel" onclick="cancelPersonToFile()">Cancel</button>
			<button id="add" onclick="savePersonToFile()">Start Chat</button>
		</div>
		<div class="connectToUser" style="background-color: <?php echo $color?>">
			<input maxlength="12" id="contact_username2" type="text" name="name" placeholder="Name"><br>
			<input id="contact_initiator" type="text" name="initiator" placeholder="Init"><br>
			<input id="contact_ipAddress2" type="text" name="ip" placeholder="Other IPs"><br>
			<input id="contact_sessionID2" type="text" name="sessionID" placeholder="Session ID">
			<button id="cancel" onclick="cancelPersonToFile()">Cancel</button>
			<button id="add" onclick="savePersonToFile2()">Connect</button>
		</div>
		<script src="/dependencies/jquery.js"></script>
		<script type="text/javascript"></script>
		<script type="text/javascript">

			function addNewPerson()
			{
				$(".addPerson").show();
				$(".contacts_list").css("opacity", "0.3");
			}

			function connect()
			{
				$(".connectToUser").show();
				$(".contacts_list").css("opacity", "0.3");
			}

			function cancelPersonToFile()
			{
				$(".addPerson").hide();
				$(".connectToUser").hide();
				$(".contacts_list").css("opacity", "1");
				document.getElementById('contact_username').value = "";
				document.getElementById('contact_ipAddress').value = "";
			}

		</script>

		<!-- Notifications -->
		
		<script type="text/javascript">
			function sendCustomMessage1() 
			{
				$("#customNotification").show();
				$(".contacts_list").css("opacity", "0.3");
			}

			function cancelSendCustomMessage()
			{
				$("#customNotification").hide();
				$(".contacts_list").css("opacity", "1");
			}

			function acceptSendCustomMessage()
			{
				if (confirm("WARNING: This message is not secure, continue to send?")) 
				{
					xhttp = new XMLHttpRequest();
					xhttp.open("POST", "/home/chat/index.php", true);
					xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					var data = "messageCustom=" + encodeURIComponent(document.getElementById('customMessage').value) + "&messageIPs=" + encodeURIComponent(document.getElementById('customIPs').value);
					xhttp.send(data);
					console.log(data);
					$("#customNotification").hide();
					$(".contacts_list").css("opacity", "1");
					document.getElementById('customMessage').value = "";
					document.getElementById('customIPs').value = "";
					alert("Message Sent Unsecurely")

				} else
				{

				}
			}

			<?php

			$customMessage = $_POST['messageCustom'];
			$customIPs = $_POST['messageIPs'];
			if (isset($customMessage) && isset($customIPs)) 
			{
				$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
				$originalPort = 5748;
				date_default_timezone_set("Asia/Dubai");
				$ips = explode(" ", $customIPs);
				$yourIP = file_get_contents("../../ip.txt");

				$message = "<span style='color: rgb(202,0,0)'>".$yourIP."</span> " . $customMessage . "<br><i>".date("h:i A")."</i>";
				for ($i=0; $i < sizeof($ips); $i++) 
				{ 
					socket_sendto($socket, $message, strlen($message), 0, $ips[$i], $originalPort);
				}
			}


			?>


		</script>

		<div id="customNotification" style="background-color: <?php echo $color?>">
			<label style="color: <?php echo $font?>">Enter Message (WARNING: Unsecure Message)</label>
			<hr>
			<input id="customMessage" type="text" name="customMessage" placeholder="Enter Message...">
			<input id="customIPs" type="text" name="ips" placeholder="Enter all IPs">
			<button onclick="cancelSendCustomMessage()">Cancel</button>
			<button onclick="acceptSendCustomMessage()">Send</button>
		</div>

		<div class="notifications">

			<!-- Notifications Header -->
			<div id="notificationsItem0-1" style="padding: 5%; color:white">
				<label>Notifications</label>
				<button id="notificationsButton" onclick="sendCustomMessage1()">Custom Not.</button><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Notifications Feed -->
			<div id="notificationsItem0-2">
				<ul type="circle" id="notificationsList">
					
				</ul>
			</div>

		</div>

		<!-- Online Users -->
		<div class="online_users">
			
			<!-- Online Users Header -->
			<hr>
			<div id="online_usersItem0-1" style="padding: 5%; color:white">
				<label>Online Users</label><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Online Users Feed -->
			<div id="online_usersItem0-2" style="color: white">
				<ul type="circle" id="list">
					
				</ul>
			</div>

		</div>

	</div>

</body>
</html>