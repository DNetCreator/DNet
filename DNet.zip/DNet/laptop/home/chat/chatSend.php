<?php

// TCP Connection
error_reporting(0);
$portNo = file_get_contents("portNo.json");
$portNo = json_decode($portNo, true);
$portNo = $portNo['port'];

$userData = file_get_contents('chatData/'.$portNo.'data.json');
$userData = json_decode($userData, true);

$ips = explode(" ", $userData['ips']);
$username = $userData['username'];
$init = $userData['initiator'];

echo "[*] Do not close this terminal until process is over\n";

// Makes Socket
while (true) 
{
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	echo "[*] Looking for hosts...\n";
	$connectedSocket = socket_connect($socket, $init, 6789);
	sleep(1);
	if ($connectedSocket == 1) {
		echo "[*] Connection Found\n";
		break;
	}
}

// Sends Public Key
$publicKey = "../../userData/".$username."/publicKey.pem";
$publicKeyFile = fopen($publicKey, 'rb');
$publicKeyData = fread($publicKeyFile, filesize($publicKey));
socket_write($socket, $publicKeyData);
socket_read($socket, 1);
fclose($publicKeyFile);

// Recieves AES Keys
$aesKeyData = socket_read($socket, 1024);
socket_write($socket, '.');
$aesIVData = socket_read($socket, 1024);
socket_write($socket, '.');

// Recieves IPs and Session ID Encrypted to Decrypt
$ipsData = socket_read($socket, 1024);
socket_write($socket, '.');
$portData = socket_read($socket, 1024);
socket_write($socket, '.');

// Get Private Key
$privateKey = "../../userData/".$username."/privateKey.pem";
$privateKeyFile = fopen($privateKey, 'rb');
$privateKeyData = fread($privateKeyFile, filesize($privateKey));
fclose($privateKeyFile);
$privateKey = openssl_get_privatekey($privateKeyData);

// Decrypts AES Keys with Private Key
openssl_private_decrypt($aesKeyData, $KEY, $privateKey);
openssl_private_decrypt($aesIVData, $IV, $privateKey);


$file = fopen('chatData/'.$portNo.'keys.json', 'wb');
$jsonData->key = $KEY;
$jsonData->iv = $IV;
$jsonDataEncoded = json_encode($jsonData);
fwrite($file, $jsonDataEncoded);
fclose($file);

$file = fopen('chatData/'.$portNo.'settings.txt', 'w');
$colors = array('pink', 'blue', 'green', 'red', 'yellow', 'gold', 'lavender', 'purple');
for ($i=0; $i < sizeof($ips); $i++) 
{ 
	fwrite($file, $ips[$i]."-".$colors[rand(0,7)]."\n");
}
fclose($file);

// Close socket
socket_close($socket);
echo "[*] Process complete. This terminal can now be closed.\n";


// Start Recv Terminal 

?>