<?php

$user = exec('whoami');

$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
$yourIP = file_get_contents("../../ip.txt");

$userData = file_get_contents("chatData/".$argv[1].'data.json');
$userData = json_decode($userData, true);
$ipArray = explode(" ", $userData['ips']);
$port = $userData['port'];
array_push($ipArray, file_get_contents("../../ip.txt"));

$originalPort = 5748;

date_default_timezone_set("Asia/Dubai");

$message = "<span style='color: rgb(202,0,0)'; line-height: 1.2em;'>".$yourIP."</span> <a href=\"/home/chat/index.php\" style=\"color: white;\">Connect to Chat</a><br><b>Init:</b> ".file_get_contents("../../ip.txt")."<br><b>Other IPs:</b> [".implode(" ", $ipArray)."]<br><b>Session ID:</b> " . $port . "<br><i>".date("h:i A")."</i>";

for ($i=0; $i < sizeof($ipArray) - 1; $i++) 
{ 
	socket_sendto($socket, $message, strlen($message), 0, $ipArray[$i], $originalPort);
}



?>