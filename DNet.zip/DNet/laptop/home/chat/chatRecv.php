<?php

// TCP Connection 
error_reporting(0);

$portNo = file_get_contents("portNo.json");
$portNo = json_decode($portNo, true);
$portNo = $portNo['port'];

// Ecrypted AES Keys with Public Key
$AESkey = substr(base64_encode(hash('sha256', random_bytes(100))), 56);
$AESiv = substr(base64_encode(hash('sha256', random_bytes(100))), 72);

// Writing and reading key data
$chatFile = file_get_contents('chatData/'.$portNo.'data.json');
$chatFile = json_decode($chatFile, true);
$ips = explode(" ", $chatFile['ips']);
$port = $chatFile['port'];
$file = fopen('chatData/'.$portNo.'keys.json', 'wb');
$jsonData->key = $AESkey;
$jsonData->iv = $AESiv;
$jsonDataEncoded = json_encode($jsonData);
fwrite($file, $jsonDataEncoded);
fclose($file);

echo "[*] Do not close this terminal until process is over\n";

$number = sizeof($ips);

for ($i=0; $i < sizeof($ips); $i++) 
{ 
	// Makes Socket
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	socket_bind($socket, file_get_contents("../../ip.txt"), 6789);
	socket_listen($socket);
	echo "[*] Listening on " . file_get_contents("../../ip.txt") . ":6789\n";
	echo "[*] Listening for ".  $number . " Connections\n";
	$connectedSocket = socket_accept($socket);
	echo "[*] Connetion Found.\n";
	
	// Recieve Public Key
	$publicKeyData = socket_read($connectedSocket, 4096);
	socket_write($connectedSocket, '.');
	$publicKey = openssl_get_publickey($publicKeyData);

	// Ecrypted AES Keys with Public Key
	openssl_public_encrypt($AESkey, $KEY, $publicKey);
	openssl_public_encrypt($AESiv, $IV, $publicKey);

	// Send AES Keys
	socket_write($connectedSocket, $KEY);
	socket_read($connectedSocket, 1);
	socket_write($connectedSocket, $IV);
	socket_read($connectedSocket, 1);

	socket_close($connectedSocket);

	sleep(1);
	$number = $number - 1;
	echo "------------------------------\n";
}

$file = fopen('chatData/'.$portNo.'settings.txt', 'w');
fclose($file);

$file = fopen('chatData/'.$portNo.'settings.txt', 'w');
$colors = array('pink', 'blue', 'green', 'red', 'yellow', 'gold', 'lavender', 'purple');
for ($i=0; $i < sizeof($ips); $i++) 
{ 
	fwrite($file, $ips[$i]."-".$colors[rand(0,7)]."\n");
}
fclose($file);

echo "[*] Process complete. This terminal can now be closed.\n";


?>