<?php

error_reporting(0);
$user = exec('whoami');
$userData = file_get_contents("/Users/".$user."/Desktop/DNet/laptop/userData/".$argv[1]."/broadcast.json");
$userData = json_decode($userData, true);
$status = $userData['status'];

$yourip = file_get_contents("../../ip.txt");
$format = $argv[1]."\t".$yourip."\t".$argv[2];
$ipFormat = explode(".", file_get_contents("../../ip.txt"));


if ($status == 'no_one') {

} else if ($status == 'contacts_only') {
	// Gets contact IP Addresses
	$file = file_get_contents("/Users/".$user."/Desktop/DNet/laptop/userData/".$argv[1]."/contacts.txt");
	$data = explode("|", $file);
	array_pop($data);
	$ips = array();
	for ($i=0; $i < sizeof($data); $i++) 
	{ 
		$ipArray = explode("-", $data[$i]);
		array_push($ips, $ipArray[1]);
	}
	for ($i=0; $i < sizeof($ips); $i++) 
	{ 
		$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
		socket_sendto($socket, $format, strlen($format), 0, $ips[$i], 5555);
		sleep(0.5);
	}

} else if ($status == 'everyone') {
	$ipArray = array();
	foreach (range(0, 256) as $ip) 
	{
		$ip2 = $ipFormat[0].'.'.$ipFormat[1].'.'.$ipFormat[2].'.'.$ip;
		array_push($ipArray, $ip2);
	}

	for ($i=0; $i < sizeof($ipArray); $i++) 
	{ 
		$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
		socket_sendto($socket, $format, strlen($format), 0, $ipArray[$i], 5555);
		sleep(0.5);
	}
}

?>