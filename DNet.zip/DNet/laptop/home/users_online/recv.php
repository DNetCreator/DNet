<?php

$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
socket_bind($socket, file_get_contents("../../ip.txt"), 5555);
//system('clear');
//echo "DO NOT CLOSE, Online Users Terminal...\n";

while (true) 
{
	// Recieve broadcast
	socket_recvfrom($socket, $buf, 1000, 0, $rip, $rport);
	// Save to file to be processed
	$onlineUsers = fopen('onlineUsersTemp.txt', 'a');
	fwrite($onlineUsers, $buf . "\n");
	fclose($onlineUsers);
}

?>