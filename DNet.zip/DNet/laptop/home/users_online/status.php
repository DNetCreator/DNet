<?php

system('sort onlineUsersTemp.txt | uniq > onlineUsers2.txt');
system('grep -v "offline" onlineUsers2.txt > onlineUsersTemp2.txt');
system('grep -v "online" onlineUsers2.txt > offlineUsers.txt');

$offlineUsers = file_get_contents('offlineUsers.txt');
$offlineUsersArr = explode("\n", $offlineUsers);

$IPsOnly = array();


for ($i=0; $i < sizeof($offlineUsersArr); $i++) 
{ 
	$ip = explode("\t", $offlineUsersArr[$i])[1];
	array_push($IPsOnly, $ip);
}
array_pop($IPsOnly);

if (sizeof($IPsOnly) != 0) 
{
	for ($i=0; $i < sizeof($IPsOnly); $i++) 
	{ 
		system('grep -v "'.$IPsOnly[$i].'" onlineUsersTemp2.txt > onlineUsers.txt');
	}

	system('cp onlineUsers.txt onlineUsersTemp.txt');
} else
{
	system('sort onlineUsersTemp.txt | uniq > onlineUsers.txt');
}





?>