<?php

// --------------------Variables for Login--------------------
session_start();
error_reporting(0);

if (isset($_SESSION['user'])) 
{
} else 
{
	die(header('Location: /login'));
}

system("cd ../users_online; php send.php " . $_SESSION['user'] . " online &");
#system("../../../bin/checkStatus");
system("cd ../users_online; php status.php");

$chatData = $_POST['chatData'];
if (isset($chatData)) 
{
	$chatData = explode('-', $chatData);
	$type = $chatData[0];
	$ipAddress = $chatData[1];

	// Make JSON data
	$fileJson = fopen('../chat/chatData.json', 'wb');
	$jsonData->type = $type;
	// $jsonData->username = $username;
	$jsonData->ipAddress = $ipAddress;
	$jsonDataEncoded = json_encode($jsonData);
	fwrite($fileJson, $jsonDataEncoded);
	fclose($fileJson);
}

// --------------------Variables for Login--------------------

$color = file_get_contents("../../userData/".$_SESSION['user']."/settings.json");
$color = json_decode($color, true);
$color = $color['color'];

$font = file_get_contents("../../userData/".$_SESSION['user']."/overallColor.json");
$font = json_decode($font, true);
$font = $font['color'];

?>

<!DOCTYPE html>
<html>
<head>
	<title>DNet | Online Users</title>
	<link rel="shortcut icon" type="image/png" href="/icons/logo.png/">
	<link rel="stylesheet" type="text/css" href="/home/users_online/index.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
</head>
<body>

	<div class="main">

		<!-- Header -->
		<div class="header" style="background-color: <?php echo $color ?>">
			<img onclick="showSidebar()" id="left_ham" src="../../icons/hamburger_lines.png">
			<img onclick="showNotifications()" id="right_ham" src="../../icons/hamburger_lines.png">
			<p style="color: <?php echo $font?>">Online Users</p>
		</div>

		<!-- Toggle Sidebar Button -->
		<script src="/dependencies/jquery.js"></script>
		<script type="text/javascript">

			function showSidebar()
			{
				if($(".sidebar").css("display") == 'block')
				{
					$(".sidebar").css("display", "none");
				} else if ($(".sidebar").css("display") == 'none')
				{
					$(".sidebar").css("display", "block");
				}
			}
			function showNotifications()
			{
				if($(".notifications").css("display") == 'block')
				{
					$(".notifications").css("display", "none");
				} else if ($(".notifications").css("display") == 'none')
				{
					$(".notifications").css("display", "block");
				}
			}
			$(document).ready(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						console.log(dataArray[0].split("\t")[0]);
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			}, 5000);
			$(document).ready(function() {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--)
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			}, 5000);

		</script>

		<!-- Sidebar Menu -->
		<div class="sidebar">
			
			<!-- User Section -->
			<div id="sidebarItem0-1" style="padding: 5%">
				<a href="/home"><img src="/icons/logo.png">
				<p><?php echo $_SESSION['user'] ?></p><br></a>
			</div>
			<hr>
			
			<!-- Main Section -->
			<a href="/home/chat"><div id="sidebarItem1-1" style="padding: 5%;">
				<p>Chat</p>
			</div></a>
			<a href="/home/file_sharing"><div id="sidebarItem1-2" style="padding: 5%;">
				<p>File Sharing</p>
			</div></a>
			<hr>

			<!-- Contacts -->
			<a href="/home/contacts"><div id="sidebarItem2-1" style="padding: 5%;">
				<p>Contacts</p>
			</div></a>
			<hr>

			<!-- Extras Section -->
			<a href="/home/users_online"><div id="sidebarItem3-1" style="padding: 5%; background-color: <?php echo $color ?>">
				<p>Online Users</p>
			</div></a>
			<a href="/home/settings"><div id="sidebarItem3-3" style="padding: 5%;">
				<p>Settings</p>
			</div></a>
			<hr>

			<!-- Help Section -->
			<a href="/home/users_online/help.txt"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Help</p>
			</div></a>
			<hr>

			<!-- Logout -->
			<a href="/home/logout"><div id="sidebarItem4-1" style="padding: 5%;">
				<p>Logout</p>
			</div></a>

		</div>

		<script type="text/javascript">
			$(document).ready(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						console.log(dataArray[0].split("\t"));
						for (var i = 0; i < dataArray.length; i++) 
						{
							username = dataArray[i].split("\t")[0];
							ipAddress = dataArray[i].split("\t")[1];
							if (dataArray[i] == "") 
							{
								continue;
							} else
							{
								var txt1 = '<div id="my_info"> \
										<b><p id="name" style="color: <?php echo $font?>">' + username +'</p></b><br> \
										<p id="ip" style="color: <?php echo $font?>">' + ipAddress + '</p> \
										<a href="#"><img id="file_sharing_icon" onclick="sendFileToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/file_sharing.png" title="Send File To User"></a> \
										<a href="#"><img id="message_icon" onclick="sendMessageToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/message.png" title="Send Message To User"></a> \
										</div>'
							$(".contacts_list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			});

			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					$(".contacts_list").empty();
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						console.log(dataArray[0].split("\t"));
						for (var i = 0; i < dataArray.length; i++) 
						{
							username = dataArray[i].split("\t")[0];
							ipAddress = dataArray[i].split("\t")[1];
							if (dataArray[i] == "") 
							{
								continue;
							} else
							{
								var txt1 = '<div id="my_info"> \
										<b><p id="name" style="color: <?php echo $font?>">' + username +'</p></b><br> \
										<p id="ip" style="color: <?php echo $font?>">' + ipAddress + '</p> \
										<a href="#"><img id="file_sharing_icon" onclick="sendFileToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/file_sharing.png" title="Send File To User"></a> \
										<a href="#"><img id="message_icon" onclick="sendMessageToUser(\'' + username + '\', \'' + ipAddress + '\')" src="../../icons/message.png" title="Send Message To User"></a> \
										</div>'
							$(".contacts_list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			}, 5000);

			function sendFileToUser(username, ipAddress)
			{
				console.log("sendFileToUser: " + username + ", " + ipAddress);
				// The data is taken. 

				// The type is Sending_File
				var type = 'send_file';
				// Type is saved along with data
				var data = type + '-' + ipAddress
				// XML Request sends to PHP
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/contacts/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "sendFileData=" + data;
				console.log(data);
				xhttp.send(data);
				setTimeout(function(){ document.location.href = '/home/file_sharing/index.php'; }, 500);
				// PHP makes JSON file with data inside it

				// The Page will redirect
				// It will read from the JSON file (Don't know how I am going to make seperate ones for shortcut and dashboard versions)
			}
			function sendMessageToUser(username, ipAddress)
			{
				console.log("sendMessageToUser: " + username + ", " + ipAddress);

				var type = 'send_message';

				var data = type + '-' + ipAddress;

				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/home/contacts/index.php", true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				var data = "chatData=" + data;
				console.log(data);
				xhttp.send(data);
				setTimeout(function(){ document.location.href = '/home/chat/index.php'; }, 500);

			}
		</script>

		<!-- Contacts -->
		<div class="contacts">
			
			<!-- Main Features -->

			<div class="contacts_list" style="background-color: <?php echo $color ?>">
							
			</div>

		</div>

		<!-- Notifications -->
		<div class="notifications">

			<!-- Notifications Header -->
			<div id="notificationsItem0-1" style="padding: 5%; color:white">
				<label>Notifications</label><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Notifications Feed -->
			<div id="notificationsItem0-2">
				<ul type="circle" id="notificationsList">
					
				</ul>
			</div>

		</div>

		<!-- Online Users -->
		<div class="online_users">
			
			<!-- Online Users Header -->
			<hr>
			<div id="online_usersItem0-1" style="padding: 5%; color:white">
				<label>Online Users</label><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Online Users Feed -->
			<div id="online_usersItem0-2" style="color: white">
				<ul type="circle" id="list">
					
				</ul>
			</div>

		</div>

	</div>

</body>
</html>