<?php

// --------------------Variables for Login--------------------
session_start();

error_reporting(0);

if (isset($_SESSION['user'])) 
{
} else 
{
	die(header('Location: /login'));
}
// --------------------Variables for Login--------------------

system("cd ../users_online; php send.php " . $_SESSION['user'] . " offline &");
#system("../../../bin/checkStatus");
system("cd ../users_online; php status.php");
system('cd ../users_online; rm onlineUsersTemp2.txt ips.txt offlineUsers.txt onlineUsers2.txt onlineUsersTemp2.txt');
system('cd ../users_online; :>| onlineUsers.txt');
session_destroy();
echo "<script>document.location.href = '/login'</script>";


?>