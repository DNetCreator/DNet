<?php

error_reporting(0);
@ini_set('display_errors', 0);
//system('clear');
//echo "DO NOT CLOSE. Recieving DNet Notifications...\n";

$laptopIP = file_get_contents("../../ip.txt");
$originalPort = 5748;

// echo "Listening on ". $laptopIP . ":" . $originalPort . "\n";

$user = exec('whoami');

$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
socket_bind($socket, $laptopIP, $originalPort);

while (true) {
	$data = socket_read($socket, 10000);
	$file = fopen('notificationsHistory.txt', 'a');
	fwrite($file, $data . " | ");
}

?>