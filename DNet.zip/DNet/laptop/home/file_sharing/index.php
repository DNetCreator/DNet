<?php

// --------------------Variables for Login--------------------
session_start();
error_reporting(0);

if (isset($_SESSION['user'])) 
{
} else 
{
	die(header('Location: /login'));
}

system("cd ../users_online; php send.php " . $_SESSION['user'] . " online &");
#system("../../../bin/checkStatus");
system("cd ../users_online; php status.php");
// --------------------Variables for Login--------------------

$color = file_get_contents("../../userData/".$_SESSION['user']."/settings.json");
$color = json_decode($color, true);
$color = $color['color'];

$font = file_get_contents("../../userData/".$_SESSION['user']."/overallColor.json");
$font = json_decode($font, true);
$font = $font['color'];


?>

<?php

$type = $_POST['type'];
if (isset($type)) 
{
	if ($type == 'send_file_end') {
		system('rm -P sendFileData.json');
		$file = fopen('sendFileData.json', 'wb');
		$jsonData->type = 'send_file_end';
		$jsonDataEncoded = json_encode($jsonData);
		fwrite($file, $jsonDataEncoded);
		fclose($$file);
	}

}

function openFileChooser()
{
	system('open ../../../Get\ Address');
}

$type = $_POST['choose_file'];
if ($type == 'choose_file') 
{
	openFileChooser();
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>DNet | File Sharing</title>
	<link rel="shortcut icon" type="image/png" href="/icons/logo.png/">
	<link rel="stylesheet" type="text/css" href="/home/file_sharing/index.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
</head>
<body>

	<div class="main">

		<!-- Header -->
		<div class="header" style="background-color: <?php echo $color ?>">
			<img onclick="showSidebar()" id="left_ham" src="../../icons/hamburger_lines.png">
			<img onclick="showNotifications()" id="right_ham" src="../../icons/hamburger_lines.png">
			<p style="color: <?php echo $font?>">File Sharing</p>
		</div>

		<!-- Toggle Sidebar Button -->
		<script src="/dependencies/jquery.js"></script>
		<script type="text/javascript">

			function showSidebar()
			{
				if($(".sidebar").css("display") == 'block')
				{
					$(".sidebar").css("display", "none");
				} else if ($(".sidebar").css("display") == 'none')
				{
					$(".sidebar").css("display", "block");
				}
			}
			function showNotifications()
			{
				if($(".notifications").css("display") == 'block')
				{
					$(".notifications").css("display", "none");
				} else if ($(".notifications").css("display") == 'none')
				{
					$(".notifications").css("display", "block");
				}
			}
			$(document).ready(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						console.log(dataArray[0].split("\t")[0]);
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+' - '+dataArray[i].split("\t")[1]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+' - '+dataArray[i].split("\t")[1]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			}, 5000);

			$(document).ready(function() {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--)
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			}, 5000);



		</script>

		<!-- Sidebar Menu -->
		<div class="sidebar">
			
			<!-- User Section -->
			<div id="sidebarItem0-1" style="padding: 5%">
				<a href="/home"><img src="/icons/logo.png">
				<p><?php echo $_SESSION['user'] ?></p><br></a>
			</div>
			<hr>
			
			<!-- Main Section -->
			<a href="/home/chat"><div id="sidebarItem1-1" style="padding: 5%;">
				<p>Chat</p>
			</div></a>
			<a href="/home/file_sharing"><div id="sidebarItem1-2" style="padding: 5%; background-color: <?php echo $color?>">
				<p>File Sharing</p>
			</div></a>
			<hr>

			<!-- Contacts -->
			<a href="/home/contacts"><div id="sidebarItem2-1" style="padding: 5%;">
				<p>Contacts</p>
			</div></a>
			<hr>

			<!-- Extras Section -->
			<a href="/home/users_online"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Online Users</p>
			</div></a>
			<a href="/home/settings"><div id="sidebarItem3-3" style="padding: 5%;">
				<p>Settings</p>
			</div></a>
			<hr>

			<!-- Help Section -->
			<a href="/home/file_sharing/help.txt"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Help</p>
			</div></a>
			<hr>

			<!-- Logout -->
			<a href="/home/logout"><div id="sidebarItem4-1" style="padding: 5%;">
				<p>Logout</p>
			</div></a>

		</div>

		<!-- File Sharing -->
		<div class="file_sharing">

			<!-- Main Features -->
			
			<div class="send_file" style="background-color: <?php echo $color?>">
				<label style="color: <?php echo $font?>">Send Files</label>
				<hr>
				<?php

					$files = $_POST['file_name'];
					$ips = $_POST['send_to_ips'];
					$port = rand(1100, 65000);

					if (isset($files) && isset($ips)) {

						$filesStatus = false;
						$ipsStatus = false;
						$isFile = false;

						// Checking if files are empty
						if (empty($files) || empty($ips)) {
							echo "<p style='text-align:left; margin-top: 5px;'>- Files or IPs not Entered</p>";
							$filesStatus = false;
							$ipsStatus = false;
						} else
						{
							$filesStatus = true;
							$ipsStatus = true;
						}

						$fileArray = explode(",", $files);
						for ($i=0; $i < sizeof($fileArray); $i++) 
						{ 
							if (is_file($fileArray[$i])) {
								$isFile = true;
							} else
							{
								echo "<p style='text-align:left; margin-top: 5px;'>- Only Files are Allowed. For Folders, use Zip File</p>";
								$isFile = false;
								break;
							}
						}

						$fileArray = explode(",", $files);
						for ($i=0; $i < sizeof($fileArray) ; $i++) 
						{ 
							if (file_exists($fileArray[$i])) {
								continue;
							} else
							{
								echo "<p style='text-align:left; margin-top: 5px;'>- File: " . $fileArray[$i] . " Doesn't Exist</p>";
								$isFile = false;
							}
						}


						if ($filesStatus == true && $ipsStatus == true && $isFile == true) 
						{
							$file = fopen('sendFile.json', 'wb');
							$jsonData->files = $files;
							$jsonData->ips = $ips;
							$jsonData->port = $port;
							$jsonDataEncoded = json_encode($jsonData);
							fwrite($file, $jsonDataEncoded);
							fclose($file);
							system("php sendNotification.php");
							system("open ../../../bin/sendFile");
						}
					}

				?>
				<form method="POST">
					<input id="file_name" type="text" name="file_name" placeholder="Enter File Address"><button type="button" onclick="openFileChooser()" id="chooseButton">Choose</button>
					<input id="send_to_ips" type="text" name="send_to_ips" placeholder="IPs"><br>
					<button id="send_button">Send</button>
				</form>
			</div>


			<script type="text/javascript" src="../../dependencies/jquery.js"></script>
			<script type="text/javascript">

				$(document).ready(function()
				{
					$.getJSON('sendFileData.json', function(results)
					{
						var type = results.type;
						// var username = results.username;
						var ipAddress = results.ipAddress;
						console.log(type == 'send_file');
						if (type == 'send_file') 
						{
							document.getElementById('send_to_ips').value = ipAddress;
							var xhttp = new XMLHttpRequest();
							xhttp.open("POST", "/home/file_sharing/index.php", true);
							xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
							var data = "type=send_file_end"
							console.log(data);
							xhttp.send(data);
						}
					});	
				});

			</script>
			<script type="text/javascript">
				function openFileChooser()
				{
					var type = 'choose_file';
					var xhttp = new XMLHttpRequest();
					xhttp.open("POST", "/home/file_sharing/index.php", true);
					xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					var data = "choose_file=" + type;
					console.log(data);
					xhttp.send(data);

				}
			</script>
			
			<div class="recieve_file" style="background-color: <?php echo $color?>">
				<label style="color: <?php echo $font?>">Receive Files</label>
				<hr>
				<?php

				$session = $_POST['session_id'];
				if (isset($session)) {
					$sessionIDStatus = false;


					// If empty
					if (empty($session)) 
					{
						echo "<p style='text-align:left; margin-top: 5px;'>- Session ID not Entered</p>";
						$sessionIDStatus = false;
					} else 
					{
						$sessionIDStatus = true;
					}


					// If numeric
					if (!(is_numeric($session))) 
					{
						echo "<p style='text-align:left; margin-top: 5px;'>- Numbers Allowed Only</p>";
						$sessionIDStatus = false;
					} else 
					{
						$sessionIDStatus = true;
					}

					// If in range
					if ($session > 65000 || $session < 1100) {
						echo "<p style='text-align:left; margin-top: 5px;'>- Session ID Range Error</p>";
						$sessionIDStatus = false;
					} else
					{
						$sessionIDStatus = true;
					}

					if ($sessionIDStatus == true) 
					{
						$file = fopen('sessionID.json', 'wb');
						$jsonData->sessionID = $session;
						$jsonData->username = $_SESSION['user'];
						$jsonDataEncoded = json_encode($jsonData);
						fwrite($file, $jsonDataEncoded);
						fclose($$file);
						system("open ../../../bin/recvFile");
					}
				} 

				?>
				<form method="POST">
					<input id="recvSessionID" type="text" name="session_id" placeholder="Session ID"><br>
					<button type="submit" id="send_button">Receive</button>
				</form>
			</div>
			
			<!-- <div class="folder_sharing">
				<a href="/home/folder_sharing"><button>Folder Sharing</button></a>
			</div> -->

		<script type="text/javascript">
			function sendCustomMessage1() 
			{
				$("#customNotification").show();
				$(".file_sharing").css("opacity", "0.3");
			}

			function cancelSendCustomMessage()
			{
				$("#customNotification").hide();
				$(".file_sharing").css("opacity", "1");
			}

			function acceptSendCustomMessage()
			{
				if (confirm("WARNING: This message is not secure, continue to send?")) 
				{
					xhttp = new XMLHttpRequest();
					xhttp.open("POST", "/home/chat/index.php", true);
					xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					var data = "messageCustom=" + encodeURIComponent(document.getElementById('customMessage').value) + "&messageIPs=" + encodeURIComponent(document.getElementById('customIPs').value);
					xhttp.send(data);
					console.log(data);
					$("#customNotification").hide();
					$(".file_sharing").css("opacity", "1");
					document.getElementById('customMessage').value = "";
					document.getElementById('customIPs').value = "";
					alert("Message Sent Unsecurely")

				} else
				{

				}
			}

			<?php

			$customMessage = $_POST['messageCustom'];
			$customIPs = $_POST['messageIPs'];
			if (isset($customMessage) && isset($customIPs)) 
			{
				$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
				$originalPort = 5748;
				date_default_timezone_set("Asia/Dubai");
				$ips = explode(" ", $customIPs);
				$yourIP = file_get_contents("../../ip.txt");

				$message = "<span style='color: rgb(202,0,0)'>".$yourIP."</span> " . $customMessage . "<br><i>".date("h:i A")."</i>";
				for ($i=0; $i < sizeof($ips); $i++) 
				{ 
					socket_sendto($socket, $message, strlen($message), 0, $ips[$i], $originalPort);
				}
			}


			?>


		</script>

		</div>

		<div id="customNotification" style="background-color: <?php echo $color?>">
			<label style="color: <?php echo $font?>">Enter Message (WARNING: Unsecure Message)</label>
			<hr>
			<input id="customMessage" type="text" name="customMessage" placeholder="Enter Message...">
			<input id="customIPs" type="text" name="ips" placeholder="Enter all IPs">
			<button onclick="cancelSendCustomMessage()">Cancel</button>
			<button onclick="acceptSendCustomMessage()">Send</button>
		</div>

		<!-- Notifications -->
		<div class="notifications">

			<!-- Notifications Header -->
			<div id="notificationsItem0-1" style="padding: 5%; color:white">
				<label>Notifications</label>
				<button id="notificationsButton" onclick="sendCustomMessage1()">Custom Not.</button><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Notifications Feed -->
			<div id="notificationsItem0-2">
				<ul type="circle" id="notificationsList">
					
				</ul>
			</div>



		</div>

		<!-- Online Users -->
		<div class="online_users">
			
			<!-- Online Users Header -->
			<hr>
			<div id="online_usersItem0-1" style="padding: 5%; color:white">
				<label>Online Users</label><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Online Users Feed -->
			<div id="online_usersItem0-2" style="color: white">
				<ul type="circle" id="list">
					
				</ul>
			</div>

		</div>

	</div>

</body>
</html>