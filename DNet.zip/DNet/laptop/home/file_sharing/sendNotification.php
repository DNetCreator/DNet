<?php

error_reporting(0);
@ini_set('display_errors', 0);

$user = exec('whoami');
// system('clear');


// Take sending signal
// starts like (./blah)

// Start this software 
$socket = socket_create(AF_INET, SOCK_DGRAM, 0);
$userData = file_get_contents("sendFile.json");
$userData = json_decode($userData, true);
$filesArray = explode(",", $userData['files']);
$ipArray = explode(" ", $userData['ips']);
$port = $userData['port'];

$filesArray2 = array();

for ($i=0; $i < sizeof($filesArray); $i++) { 
	$basename = basename($filesArray[$i]);
	array_push($filesArray2, $basename);
}

$yourIP = file_get_contents("../../ip.txt");

date_default_timezone_set("Asia/Dubai");

$originalPort = 5748;
$message = "<span style='color: rgb(202,0,0); line-height: 1.2em;'>".$yourIP."</span> <a href=\"/home/file_sharing/index.php\" style=\"color: white;\">Recieve File<a><br><b>File:</b> (".implode(', ', $filesArray2).")<br><b>Session ID:</b> " . $port . "<br><i>".date("h:i A")."</i>";

// Notification through udp
for ($i=0; $i < sizeof($ipArray); $i++)
{
	socket_sendto($socket, $message, strlen($message), 0, $ipArray[$i], $originalPort);
	//echo "Notification: " . $message . "\n";
}


// close



?>