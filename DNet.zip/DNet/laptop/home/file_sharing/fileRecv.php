<?php

system('clear');
$user = exec('whoami');

$userData = file_get_contents("sessionID.json");
$userData = json_decode($userData,true);

$ip = file_get_contents("../../ip.txt");
$port = $userData['sessionID'];
$username = $userData['username'];

$publicKey = '/Users/'.$user.'/Desktop/DNet/laptop/userData/'.$username.'/publicKey.pem';
$privateKey = '/Users/'.$user.'/Desktop/DNet/laptop/userData/'.$username.'/privateKey.pem';

// --------------------------------------------------

// Construct Socket
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_bind($socket, $ip, $port);
echo "[*] Looking for connections on ".$ip.":".$port." ...\n";
socket_listen($socket, 0);
$connectedSocket = socket_accept($socket);
echo "[*] Connection found.\n";

// Get private key 
$privateKeyFile = fopen($privateKey, 'rb');
$privateKeyData = fread($privateKeyFile, 4100);
$privateKey = openssl_get_privatekey($privateKeyData);

// ------------------------Recieving------------------------------
// send public key
$publicKeyFile = fopen($publicKey, 'rb');
$publicKey = fread($publicKeyFile, 4096);
fclose($publicKeyFile);
socket_write($connectedSocket, $publicKey);
socket_read($connectedSocket, 1);

// Recieve AES Keys
$key = socket_read($connectedSocket, 2048);
socket_write($connectedSocket, '.');
$iv = socket_read($connectedSocket, 2048);
socket_write($connectedSocket, '.');

// Recieve File Amount
$fileAmount = socket_read($connectedSocket, 1024);
socket_write($connectedSocket, '.');

// Decrypt AES Keys
$key = openssl_private_decrypt($key, $KEY, $privateKey);
$iv = openssl_private_decrypt($iv, $IV, $privateKey);

// Decrypt File Amount
$fileAmount = openssl_private_decrypt($fileAmount, $FILEAMOUNT, $privateKey);

// Arrays
$fileOriginalNamesArray = array();
$filesToBeDecArray = array();

echo "[*] Do not close this terminal until process is over\n";

for ($i=0; $i < $FILEAMOUNT; $i++) 
{ 
	// Recieve filename
	$filename = socket_read($connectedSocket, 1024);
	socket_write($connectedSocket, '.');

	// Recieve filesize
	$filesize = socket_read($connectedSocket, 1024);
	socket_write($connectedSocket, '.');

	// Decrypt file name
	$filename = openssl_private_decrypt($filename, $FILENAME, $privateKey);

	// Decrypt filesize
	$filesize = openssl_private_decrypt($filesize, $FILESIZE, $privateKey);

	$newFile = fopen("/Users/".$user."/Downloads/".$FILENAME."enc", 'wb');
	$RecvDataLength = 0;

	echo "\n---------- Recieve File ----------\n";

	while ($RecvDataLength < $FILESIZE) 
	{
		$data = socket_read($connectedSocket, 25000); 
		fwrite($newFile, $data);
		$calc = $RecvDataLength/$FILESIZE * 100;
		echo "[*] " . substr($calc, 0, 2) . "% Recieved" .  "\n";
		$RecvDataLength += strlen($data);	
	}

	echo "[*] 100% recieved\n";
	fclose($newFile);

	// Recieve file
	$fileToRecieve = "/Users/".$user."/Downloads/".$FILENAME;
	$file =  $fileToRecieve . "enc";

	array_push($fileOriginalNamesArray, $fileToRecieve);
	array_push($filesToBeDecArray, $file);

	sleep(1);

}
// ------------------------Recieving------------------------------

// ----------------------Decryption----------------------------

for ($i=0; $i < $FILEAMOUNT; $i++) 
{ 
	echo "\n---------- Decrypt File ----------\n";
	$newFile = fopen($filesToBeDecArray[$i], 'rb');
	$anotherFile = fopen($fileOriginalNamesArray[$i], 'wb');

	for ($j=0; $j < filesize($filesToBeDecArray[$i]); $j += 33344) 
	{ 
		$chunk = fread($newFile, 33344);
		$chunkDec = openssl_decrypt($chunk, 'aes-256-cbc', $KEY, 0, $IV);
		fwrite($anotherFile, $chunkDec);
		$calc = $j/filesize($filesToBeDecArray[$i]) * 100;
		echo "[*] " . substr($calc, 0, 2) . "% Decrypted" .  "\n"; 
	}

	fclose($newFile);
	fclose($anotherFile);
	echo "[*] File " . $fileOriginalNamesArray[$i] . " Encrypted\n";
}

// ----------------------Decryption----------------------------

for ($i=0; $i < $FILEAMOUNT ; $i++) { 
	system('rm "' . $filesToBeDecArray[$i] . '"');
}

// Decrypt file 
echo "[*] Files recieved in downloads folder.\n";
socket_close($socket);
echo "[*] Process complete. This terminal can now be closed.\n";

?>