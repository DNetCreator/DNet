<?php

system('clear');
$user = exec('whoami');
error_reporting(0);

$userData = file_get_contents("sendFile.json");
$userData = json_decode($userData,true);

$ipArray = explode(" ", $userData['ips']);
$fileToSend = $userData['files'];
$port = $userData['port'];


// Arrays
$fileToSendArray = explode(",", $fileToSend);
$fileToSendEncArray = array();
$fileSizeArray = array();


// AES passwords 
$AESkey = substr(base64_encode(hash('sha256', random_bytes(100))), 56);
$AESiv = substr(base64_encode(hash('sha256', random_bytes(100))), 72);
echo "[*] Generating random AES keys\n";

// ----------------------Encryption----------------------------

echo "[*] Do not close this terminal until process is over\n";

for ($i=0; $i < sizeof($fileToSendArray); $i++) 
{ 
	// Naming normal and encrypted file
	$filename = fopen($fileToSendArray[$i], 'rb');
	$filenameEnc = fopen($fileToSendArray[$i] . 'enc', 'wb');

	// Getting the filesize and encryption file
	for ($j = 0; $j < filesize($fileToSendArray[$i]); $j += 25000) 
	{ 
		$chunk = fread($filename, 25000);
		$chunkEnc = openssl_encrypt($chunk, 'aes-256-cbc', $AESkey, 0, $AESiv); 
		fwrite($filenameEnc, $chunkEnc);
		$calc = $j/filesize($fileToSendArray[$i]) * 100;
		echo "[*] " . substr($calc, 0, 2) . "% Encrypted" .  "\n";	
	}

	echo "[*] File " . $fileToSendArray[$i] . " Encrypted\n";
	fclose($filename);
	fclose($filenameEnc);

	// Saving variables to arrays
	$filesize = filesize($fileToSendArray[$i] . 'enc');
	array_push($fileSizeArray, $filesize);
	$newFiles = $fileToSendArray[$i] . 'enc';
	array_push($fileToSendEncArray, $newFiles);
}

// ----------------------Encryption----------------------------
$fileAmount = sizeof($fileToSendArray);
// ------------------------Sending------------------------------
for ($i=0; $i < sizeof($ipArray); $i++) 
{
	while (true) {
		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		echo "[*] Looking for hosts...\n";
		$connectedSocket = socket_connect($socket, $ipArray[$i], $port);
		sleep(1);
		if ($connectedSocket == 1) {
			break;
		}
	}
	echo "[*] Connected to host: ".$ipArray[$i].":".$port . "\n";

	// Get public key
	$publicKey = socket_read($socket, 4096);
	$publicKey = openssl_get_publickey($publicKey);
	socket_write($socket, ".");

	// Encrypt AES keys
	$publicKeyEncryptKey = openssl_public_encrypt($AESkey, $KEY, $publicKey);
	$publicKeyEncryptIV = openssl_public_encrypt($AESiv, $IV, $publicKey);

	// Encrypt File Amount
	$publicKeyEncryptFileAmount = openssl_public_encrypt($fileAmount, $FILEAMOUNT, $publicKey);

	// Send AES Keys
	socket_write($socket, $KEY);
	echo "Key Send\n";
	socket_read($socket, 1);
	socket_write($socket, $IV);
	echo "IV Send\n";
	socket_read($socket, 1);


	// Send File Amount
	socket_write($socket, $FILEAMOUNT);
	echo "File Amount Send\n";
	socket_read($socket, 1);

	sleep(0.4);

	for ($j=0; $j < $fileAmount; $j++) 
	{ 
		// Encrypt file name
		$basename = basename($fileToSendArray[$j]);
		$publicKeyEncryptBasename = openssl_public_encrypt($basename, $BASENAME, $publicKey);

		// Encrypt file size
		$publicKeyEncryptFilesize = openssl_public_encrypt($fileSizeArray[$j], $FILESIZE, $publicKey);


		// Send filename
		socket_write($socket, $BASENAME);
		socket_read($socket, 1);

		// Send filesize
		socket_write($socket, $FILESIZE);
		socket_read($socket, 1);

		// ------------------------------------------------

		// ----- Start Sending File ------
		echo "\n---------- Send File ----------\n";
		
		$filename = fopen($fileToSendEncArray[$j], 'rb');
		$dataSentLength = 0;

		// Send File
		while ($dataSentLength < $fileSizeArray[$j]) 
		{
			
			$chunk = fread($filename, 25000);
			socket_write($socket, $chunk);
			$calc = $dataSentLength/filesize($fileToSendEncArray[$j]) * 100;
			echo "[*] " . substr($calc, 0, 2) . "% Sent" .  "\n";
			$dataSentLength += strlen($chunk);
		}

		echo "[*] 100% Sent\n";
		fclose($filename);
		echo "[*] " . $fileToSendArray[$j] . " Sent.\n";

		sleep(1);
	}

	sleep(1);

}
// ------------------------Sending------------------------------
socket_close($socket);
for ($i=0; $i < sizeof($fileToSendArray); $i++) { 
	system('rm "' . $fileToSendArray[$i] . 'enc"');
}
echo "[*] Process complete. This terminal can now be closed.\n";
exit();
?>