<?php

// --------------------Variables for Login--------------------
session_start();
error_reporting(0);

if (isset($_SESSION['user'])) 
{
} else 
{
	die(header('Location: /login'));
}

$color = file_get_contents("../../userData/".$_SESSION['user']."/settings.json");
$color = json_decode($color, true);
$color = $color['color'];

$font = file_get_contents("../../userData/".$_SESSION['user']."/overallColor.json");
$font = json_decode($font, true);
$font = $font['color'];

system("cd ../users_online; php send.php " . $_SESSION['user'] . " online &");
#system("../../../bin/checkStatus");
system("cd ../users_online; php status.php");
// --------------------Variables for Login--------------------

$data = file_get_contents('../../userData/'.$_SESSION['user'].'/broadcast.json');
$data = json_decode($data, true);
$status = $data['status'];
$info = "UNSET";
if ($status == "no_one") 
{
	$info = "No One";
	system("cd ../users_online; php send.php " . $_SESSION['user'] . " offline &");
	system("echo ''");
	#system("../../../bin/checkStatus");
	system("cd ../users_online; php status.php");
	system('cd ../users_online; rm onlineUsers.txt onlineUsersTemp.txt ips.txt offlineUsers.txt onlineUsers2.txt');
} elseif ($status == "contacts_only") 
{
	$info = "Contacts Only";
} elseif ($status == "everyone") 
{
	$info = "Everyone";
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>DNet | Settings</title>
	<link rel="shortcut icon" type="image/png" href="/icons/logo.png/">
	<link rel="stylesheet" type="text/css" href="/home/settings/index.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
</head>
<body>

	<div class="main">

		<!-- Header -->
		<div class="header" style="background-color: <?php echo $color?>">
			<img onclick="showSidebar()" id="left_ham" src="../../icons/hamburger_lines.png">
			<img onclick="showNotifications()" id="right_ham" src="../../icons/hamburger_lines.png">
			<p style="color: <?php echo $font?>">Settings</p>
		</div>

		<!-- Toggle Sidebar Button -->
		<script src="/dependencies/jquery.js"></script>
		<script type="text/javascript">

			function showSidebar()
			{
				if($(".sidebar").css("display") == 'block')
				{
					$(".sidebar").css("display", "none");
				} else if ($(".sidebar").css("display") == 'none')
				{
					$(".sidebar").css("display", "block");
				}
			}
			function showNotifications()
			{
				if($(".notifications").css("display") == 'block')
				{
					$(".notifications").css("display", "none");
				} else if ($(".notifications").css("display") == 'none')
				{
					$(".notifications").css("display", "block");
				}
			}
			$(document).ready(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						console.log(dataArray[0].split("\t")[0]);
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("\n");
						$('#list li').remove();
						for (var i = 0; i < dataArray.length; i++) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i].split("\t")[0]+'</li>';
								$("#list").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/users_online/onlineUsers.txt", true);
				xhttp.send();
			}, 5000);
			$(document).ready(function() {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--) 
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			});
			setInterval(function()
			{
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() 
				{
					if (this.readyState == 4 && this.status == 200) 
					{
						var data = this.responseText;
						dataArray = data.split("|");
						$('#notificationsList li').remove();
						$('#notificationsList hr').remove();
						for (var i = dataArray.length-2; i >=0 ; i--)
						{
							if (dataArray[i] == "") {
								continue;
							} else
							{
								txt1 = '<li style="padding: 0.5vh"><span style="color:#00ff00">•</span> '+dataArray[i]+'</li><hr>';
								$("#notificationsList").append(txt1);
							}
						}
					}
				};
				xhttp.open("POST", "/home/file_sharing/notificationsHistory.txt", true);
				xhttp.send();
			}, 5000);

		</script>

		<!-- Sidebar Menu -->
		<div class="sidebar">
			
			<!-- User Section -->
			<div id="sidebarItem0-1" style="padding: 5%">
				<a href="/home"><img src="/icons/logo.png">
				<p><?php echo $_SESSION['user'] ?></p><br></a>
			</div>
			<hr>
			
			<!-- Main Section -->
			<a href="/home/chat"><div id="sidebarItem1-1" style="padding: 5%;">
				<p>Chat</p>
			</div></a>
			<a href="/home/file_sharing"><div id="sidebarItem1-2" style="padding: 5%;">
				<p>File Sharing</p>
			</div></a>
			<hr>

			<!-- Contacts -->
			<a href="/home/contacts"><div id="sidebarItem2-1" style="padding: 5%">
				<p>Contacts</p>
			</div></a>
			<hr>

			<!-- Extras Section -->
			<a href="/home/users_online"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Online Users</p>
			</div></a>
			<a href="/home/settings"><div id="sidebarItem3-3" style="padding: 5%; background-color: <?php echo $color?>">
				<p>Settings</p>
			</div></a>
			<hr>

			<!-- Help Section -->
			<a href="/home/settings/help.txt"><div id="sidebarItem3-1" style="padding: 5%;">
				<p>Help</p>
			</div></a>
			<hr>

			<!-- Logout -->
			<a href="/home/logout"><div id="sidebarItem4-1" style="padding: 5%;">
				<p>Logout</p>
			</div></a>

		</div>
		<script>

	</script>

		<script type="text/javascript">
			
		</script>

		<!-- Contacts -->
		<div class="chat">

			<div class="contacts_list" style="color: <?php echo $font?>; background-color: <?php echo $color ?>;">
				<form method="POST">


					<?php 

						$change_color = $_POST['change_color'];
						$new_username = $_POST['new_username'];
						$old_password = $_POST['old_password'];
						$new_password = $_POST['new_password'];
						$confirm_password = $_POST['confirm_password'];
						$password = $_POST['password'];
						$broadcast = $_POST['radio'];
						$overallFontColor = $_POST['overall'];
						$button2 = $_POST['button2'];


						if (isset($button2)) 
						{

							if (!empty(isset($change_color)))
							{
								echo "<p style='text-align:left; margin-top: 5px;'>Settings Saved</p>";
								if (strlen($change_color) != 0) {
									$file = fopen("../../userData/".$_SESSION['user']."/settings.json", 'wb');
									$jsonData->color = $change_color;
									$jsonDataEncoded = json_encode($jsonData);
									fwrite($file, $jsonDataEncoded);
								}
							}

							if (!empty(isset($overallFontColor)))
							{
								if ($overallFontColor == 'white') 
								{
									$jsonData->color = 'white';
									$jsonDataEncoded = json_encode($jsonData);
									file_put_contents('../../userData/'.$_SESSION['user'].'/overallColor.json', $jsonDataEncoded);
								} elseif ($overallFontColor == 'black') 
								{
									$jsonData->color = 'black';
									$jsonDataEncoded = json_encode($jsonData);
									file_put_contents('../../userData/'.$_SESSION['user'].'/overallColor.json', $jsonDataEncoded);
								}
							}

							if (!empty(isset($new_username))) 
							{

								//system("cd ../users_online; php send.php " . $_SESSION['user'] . " offline &");
								//system("cd ../../../bin; ./checkStatus &");
								//system('cd ../users_online; rm onlineUsersTemp.txt ips.txt offlineUsers.txt onlineUsers2.txt');
								//system('cd ../users_online; :>| onlineUsers.txt');

								// Check for other accounts with same name
								$getDirs = file_get_contents("../../userData/directories.txt");
								$getDirsArray = explode("\n", $getDirs);
								for ($i=0; $i < sizeof($getDirsArray); $i++) 
								{ 
									if ($new_username . "/" == $getDirsArray[$i] && strlen($new_username) > 0) 
									{
										echo "<p style='text-align:left; margin-top: 5px'>Username Exists</p>";
									}
								}
								
								// Update username in login.json
								if (strlen($new_username) != 0) {
									$userData = file_get_contents('../../userData/'.$_SESSION['user'].'/login.json');
									$userData = json_decode($userData, true);
									$userData[0]['username'] = $new_username;
									$newJsonString = json_encode($userData);
									file_put_contents('../../userData/'.$_SESSION['user'].'/login.json', $newJsonString);

									// Rename folder to new username
									rename('../../userData/'.$_SESSION['user'], '../../userData/'.$new_username);
								
									// Change session name into new username
									$_SESSION['user'] = $new_username;
								}
							}

							if (!empty(isset($old_password)) && !empty(isset($new_password)) && !empty(isset($confirm_password)))
							{
								$userData = file_get_contents('../../userData/'.$_SESSION['user'].'/login.json');
								$userData = json_decode($userData, true);
								$password = $userData['password'];
								if (hash('sha256',$old_password) == $password) 
								{
									if ($new_password == $confirm_password) 
									{
										// Get encryption keys file 
										$encryption_keys = file_get_contents('../../userData/'.$_SESSION['user'].'/encryption_keys.json');

										// Decrypt with old password
										$keysDecrypted = openssl_decrypt($encryption_keys, 'aes-256-ecb', $old_password);
										$keys = json_decode($keysDecrypted, true);

										// encrypt with new password
										$key = $keys['key'];
										$iv = $keys['iv'];

										// put back into encryption fil
										$jsonData->key = $key;
										$jsonData->iv = $iv;
										$jsonDataEncoded = json_encode($jsonData);
										$keysEncrypted = openssl_encrypt($jsonDataEncoded, 'aes-256-ecb', $new_password);
										file_put_contents('../../userData/'.$_SESSION['user'].'/encryption_keys.json', $keysEncrypted);

										// Update loginjson
										$userData['password'] = hash('sha256', $confirm_password);
										$newJsonString = json_encode($userData);
										file_put_contents('../../userData/'.$_SESSION['user'].'/login.json', $newJsonString);
									} else
									{
										echo "<p style='text-align:left; margin-top: 5px'>Incorrect Password</p>";
									}
								}
							}

							if (!empty(isset($broadcast)))
							{
								$file = fopen('../../userData/'.$_SESSION['user'].'/broadcast.json', 'wb');
								if ($broadcast == "no_one") 
								{
									$jsonData->status = $broadcast;
									$info = "No One";
									system("cd ../users_online; php send.php " . $_SESSION['user'] . " offline &");
									system("echo ''");
									#system("../../../bin/checkStatus");
									system("cd ../users_online; php status.php");
									system('cd ../users_online; rm onlineUsers.txt onlineUsersTemp.txt ips.txt offlineUsers.txt onlineUsers2.txt');
								} elseif ($broadcast == "contacts_only") 
								{
									$jsonData->status = $broadcast;
									$info = "Contacts Only";
								} elseif ($broadcast == "everyone") 
								{
									$jsonData->status = $broadcast;
									$info = "Everyone";
								}
								fwrite($file, json_encode($jsonData));
								fclose($file);
							}

						}

					?>

					<!-- Changing Color Setting Section -->

					<form method="POST">
					
						<div class="color">
							<label>Change Color</label><br><br>
							<input type="text" name="change_color" placeholder="Color Value -- e.g #efefef"><p id="color_p"><a href="https://www.w3schools.com/colors/colors_picker.asp" style = "color: <?php echo $font ?>" target="_blank">Show Color Picker</a></p><br>
						</div>

						<div class="color">
							<label>Overall Font Color</label><br>
							<input id="radio" type="radio" name="overall" value="white">White
							<input id="radio" type="radio" name="overall" value="black">Black<br>
						</div>


						<!-- Changing Username Section -->

						<div class="color">
							<label>Change Username</label><br><br>
							<input type="text" name="new_username" placeholder="New Username">
						</div>

						<!-- Changing Password Section -->

						<div class="color">
							<label>Change Password</label><br><br>
							<input type="password" name="old_password" placeholder="Old Password"><br><br>
							<input type="password" name="new_password" placeholder="New Password"><br><br>
							<input type="password" name="confirm_password" placeholder="Confirm New Password">
						</div>

						<div class="color">
							<label>Who Can See You're Online</label><br>
							<input id="radio" type="radio" name="radio" value="no_one">No One<br>
							<input id="radio" type="radio" name="radio" value="contacts_only">Contacts Only<br>
							<input id="radio" type="radio" name="radio" value="everyone">Everyone
							<p>Current: <? echo $info ?></p><br>
						</div>

						<div class="color">
							<label>Save Changes</label><br>
							<button type="submit" name="button2" style="margin-top: 10px; width: 60%;">Submit</button>
						</div>

					</form>
					<!-- Changing Encryption Keys -->

					<?php 

					if (isset($_POST['button'])) 
					{
						system('openssl genrsa -out ../../userData/'.$_SESSION['user'].'/privateKey.pem 4096');
						system('openssl rsa -in ../../userData/'.$_SESSION['user'].'/privateKey.pem -pubout > ../../userData/'.$_SESSION['user'].'/publicKey.pem');
					}

					?>

					<form method="POST">
						<div class="color">
							<label>Change Encryption Keys</label><br><br>
							<button name="button" id="button_color">Change</button>
						</div>
					</form>

					<!-- Who to Broadcast Section -->

				</form>

			</div>

		</div>

		<!-- Notifications -->
		<div class="notifications">

			<!-- Notifications Header -->
			<div id="notificationsItem0-1" style="padding: 5%; color:white">
				<label>Notifications</label><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Notifications Feed -->
			<div id="notificationsItem0-2">
				<ul type="circle" id="notificationsList">
					
				</ul>
			</div>

		</div>

		<!-- Online Users -->
		<div class="online_users">
			
			<!-- Online Users Header -->
			<hr>
			<div id="online_usersItem0-1" style="padding: 5%; color:white">
				<label>Online Users</label><br>
			</div>
			<hr style="margin-top: 0%;">

			<!-- Online Users Feed -->
			<div id="online_usersItem0-2" style="color: white">
				<ul type="circle" id="list">
					
				</ul>
			</div>

		</div>

	</div>

</body>
</html>