<?php

// Route to login page
header("Location: /login")

?>