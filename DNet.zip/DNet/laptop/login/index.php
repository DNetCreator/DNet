<?php

session_start();
error_reporting(0);
@ini_set('display_errors', 0);

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="image/png" href="/icons/logo.png">
	<title>DNet | Login</title>
	<link rel="stylesheet" type="text/css" href="/login/index.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
</head>
<body>
	<!-- Header -->
	<div class="header">
		<p>Login</p>
	</div>	
	<!-- Login Div -->
	<div class="login_div">		
		<!-- DNet Logo -->
		<div class="dnet_logo">
			<svg height="100%" width="100%">
	  			<circle cx="49%" cy="49%" r="20%" stroke="black" stroke-width="2%" fill="rgb(202,0,0)" />
			</svg> 
		</div>

		<div id="errors">
			<?php 

				$username = $_POST['username_field'];
				$password = $_POST['password_field'];

				if (isset($username) && isset($password)) 
				{
					if (empty($username) || empty($password)) {
						echo "<p>Enter all Fields</p>";
					}
					$userData = file_get_contents("../userData/".$username."/login.json");
					$userData = json_decode($userData,true);
					$usernameHashed = $userData['username']; 
					$passwordHashed = $userData['password'];
					if (hash('sha256', $password) == $passwordHashed) 
					{
						$_SESSION['user'] = $username;
						echo "<script>window.location = '/home'</script>";
					} else
					{
						echo "<p>Incorrect Login</p>";
					}

				}

			?>
		</div>

		<form method="POST">
			<input id="username_field" type="text" name="username_field" placeholder="Username">
			<input id="password_field" type="password" name="password_field" placeholder="Password">
			<button id="login_button" type="submit">Login</button><br><br>
		</form>

		<!-- Register -->
		<a href="/signup"><p>Register</p></a>
	</div>

	<script type="text/javascript">
		
	</script>

</body>
</html>