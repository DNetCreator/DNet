<?php 

session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="image/png" href="/icons/logo.png">
	<title>DNet | Signup</title>
	<link rel="stylesheet" type="text/css" href="/signup/index.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
</head>
<body>
	<!-- Header -->
	<div class="header">
		<p>Signup</p>
	</div>
	<!-- Signup Div -->
	<div class="signup_div">
		<!-- DNet Logo -->
		<div class="dnet_logo">
			<svg height="100%" width="100%">
	  			<circle cx="49%" cy="49%" r="20%" stroke="black" stroke-width="2%" fill="rgb(202,0,0)" />
			</svg> 
		</div>
		<!-- Username Field -->
		<div id="errors" style="line-height: 20px;">
			<?php

			error_reporting(0);

			$username = $_POST['username_field'];
			$password = $_POST['password_field'];
			$confirmPassword = $_POST['confirm_password_field'];
			$getDirs = system("cd ../userData; ls -d */ > directories.txt");
			$getDirs = file_get_contents("../userData/directories.txt");
			$getDirsArray = explode("\n", $getDirs);

			if (isset($username) && isset($password) && isset($confirmPassword))
			{

				$empty = true;

				if (empty($username) || empty($password) || empty($confirmPassword)) 
				{
					echo "<p style='style='text-align:left; margin-top: 5px'>Enter all Fields<p>";
				} elseif (!empty($username) && !empty($password) && !empty($confirmPassword)) 
				{
					$empty = false;
				}

				for ($i=0; $i < sizeof($getDirsArray); $i++) 
				{ 
					if ($username . "/" == $getDirsArray[$i] && strlen($username) > 0) 
					{
						echo "<p style='style='text-align:left; margin-top: 5px'>Username Exists</p>";
						$empty = true;
						break;
					}
				}

				if ($password != $confirmPassword) 
				{
					echo "<p style='style='text-align:left; margin-top: 5px'>Password Mismatch</p>";
				}

				
				if ($password == $confirmPassword && $empty == false) 
				{	
					$username = str_replace(" ", "_", $username);
					$_SESSION['user'] = $username;
					system('mkdir ../userData/'.$username);
					$file = fopen('../userData/'.$username.'/login.json', 'wb');
					$jsonData->username = $username;
					$jsonData->password = hash('sha256', $confirmPassword);
					$jsonDataEncoded = json_encode($jsonData);
					fwrite($file, $jsonDataEncoded);
					fclose($file);
					$file = fopen('../userData/'.$username.'/broadcast.json', 'wb');
					$jsonData->status = 'contacts_only';
					$jsonDataEncoded = json_encode($jsonData);
					fwrite($file, $jsonDataEncoded);
					fclose($file);
					system('openssl genrsa -out ../userData/'.$username.'/privateKey.pem 4096');
					system('openssl rsa -in ../userData/'.$username.'/privateKey.pem -pubout > ../userData/'.$username.'/publicKey.pem');
					echo "<script>document.location.href = '/home';</script>";
				} 
			}
			?>
		</div>

		<!-- Username Field -->
		<form method="POST">
			<input id="username_field" type="text" name="username_field" placeholder="Username">		
			<input id="password_field" type="password" name="password_field" placeholder="Password">
			<input id="confirm_password_field" type="password" name="confirm_password_field" placeholder="Confirm Password">
			<button id="signup_button" type="submit">Register</button>
		</form>
	</div>

</body>
</html>



